const Resource = require('resources.js');
const DepartmentResource = require('./DepartmentResource');
const DivisionResource = require('./DivisionResource');

class UserResource extends Resource {
    toArray() {
        let doc = {
            _id: this._id || null,
            role: this.role || null,
            name: this.name || null,
            email: this.email || null,
            mobile: this.mobile || null,
            department_id: this.department_id || null,
            division_id: this.division_id || null,
            image: this.image || null,
            status: this.status || null,
            email_verified_at: this.email_verified_at || null,
            mobile_verified_at: this.mobile_verified_at || null,
            created_at: this.created_at || null,
            updated_at: this.updated_at || null,
        }

        if (this.image !== undefined) {
            doc.image_path = global.CONFIG.app.url + '/public/uploads/users/profile/' + this.image;
        } else {
            doc.image_path = global.CONFIG.app.url + '/public/images/placeholder.png';
        }

        if (this.department !== undefined) {
            doc.department = new DepartmentResource(this.department).exec();
        }

        if (this.division !== undefined) {
            doc.division = new DivisionResource(this.division).exec();
        }

        return doc;
    }
}

module.exports = UserResource;