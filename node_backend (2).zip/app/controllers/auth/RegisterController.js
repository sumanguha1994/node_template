const helpers = require('../../common/helpers');
const User = require('../../models/User');
const UserJoining = require('../../models/UserJoining');
const Department = require('../../models/Department');
const Division = require('../../models/Division');
const OtpVerification = require('../../models/OtpVerification');

const UserResource = require('../../resources/UserResource');
const UserJoiningResource = require('../../resources/UserJoiningResource');
const DepartmentResource = require('../../resources/DepartmentResource');
const DivisionResource = require('../../resources/DivisionResource');

const RegisterController = require('./RegisterController');

const self = module.exports = {
    fetchMaster: async function(req, resp) {
        let data = {};
        try {
            let rules = {
                token: `required|exists:user_joinings,token`,
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            const uj = await validateUserJoiningToken(req.body.token);
            if (uj.status == true) {
                data.user_joining = new UserJoiningResource(uj.user_joining).exec();
            } else {
                return resp.status(200).send({ status: 'error', message: uj.message, data: data });
            }

            data.departments = [];
            await Department.find({ 'status': "active", 'deleted_at': null }, '').sort({ 'name': 1 }).exec().then(function(departments) {
                return data.departments = DepartmentResource.collection(departments);
            });

            data.divisions = [];
            await Division.find({ 'status': "active", 'deleted_at': null }, '').sort({ 'name': 1 }).exec().then(function(divisions) {
                return data.divisions = DivisionResource.collection(divisions);
            });

            return resp.status(200).send({ status: 'success', message: "Success", data: data });
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },

    submit: async function(req, resp, next, otp_verification = false) {
        let data = {};
        try {
            let rules = {
                token: `required|exists:user_joinings,token`,
                // department_id: `required|mongoId|exists:departments,_id`,
                password: `required|length:${global.CONFIG.rules.password.maxlength},${global.CONFIG.rules.password.minlength}|same:password_confirmation`,
                password_confirmation: `required|length:${global.CONFIG.rules.password.maxlength},${global.CONFIG.rules.password.minlength}`,
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            /** Validating Registration Toked */
            let user_joining = null;
            const uj = await validateUserJoiningToken(req.body.token);
            if (uj.status == true) {
                user_joining = uj.user_joining;
            } else {
                return resp.status(200).send({ status: 'error', message: uj.message, data: data });
            }

            let reg_document = {
                'role': user_joining.role,
                'name': user_joining.data.name,
                'email': user_joining.data.email,
                'mobile': user_joining.data.mobile,
                'password': await helpers.bcryptMake(req.body.password),
                'department_id': user_joining.data.department_id,
                'division_id': user_joining.data.division_id,
            };

            /** Validating Email Address */
            const email_ex = await validateUserDataForRege('email', reg_document.email);
            if (!email_ex.status) {
                return resp.status(200).send({ status: 'error', message: email_ex.message });
            }

            /** Validating Mobile Number */
            const mobile_ex = await validateUserDataForRege('mobile', reg_document.mobile);
            if (!mobile_ex.status) {
                return resp.status(200).send({ status: 'error', message: mobile_ex.message });
            }

            if (otp_verification == false) {
                // const otp = await helpers.generateRandNumber(111111, 999999)
                const otp = 111111
                const content = `${otp} is your one-time password for registration in CYTE. The otp is only valid for 20 min`

                if (helpers.sendSms(content, reg_document.mobile)) {
                    let otp_document = {
                        'email': reg_document.email,
                        'mobile': reg_document.mobile,
                        'otp': otp,
                        'type': 'user-register',
                        'token': await helpers.generateRandomString(60),
                        'data': req.body,
                    }

                    await OtpVerification.deleteMany({ 'email': reg_document.email, 'mobile': reg_document.mobile, 'type': 'user-register' }).exec();

                    await OtpVerification.create(otp_document, async function(e, details) {
                        if (e) return resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });

                        return resp.status(200).json({
                            'status': "otpverification",
                            'message': "An OTP has been sent to your mobile number",
                            data: {
                                token: details.token,
                                mobile: details.mobile,
                                email: details.email,
                            }
                        });
                    })

                    return;
                } else {
                    return resp.status(200).send({ status: 'error', message: 'The otp cannot be sent. Please try again later', data: data });
                }
            } else {
                reg_document.mobile_verified_at = Date.now();
            }


            User.create(reg_document, async function(e, details) {
                if (e) return resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });

                await UserJoining.updateOne({ _id: user_joining._id }, { used_at: Date.now() }).exec();

                if (req.body.verification_token) {
                    await OtpVerification.deleteOne({ token: req.body.verification_token }).exec();
                }

                data.user = new UserResource(details).exec();
                data.token = await helpers.generateJwtToken({ 'user_id': details._id, 'email': details.email, 'role': details.role });
                return resp.status(200).json({ 'status': "success", 'message': "Your account created successfully", data: data });
            })
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },

    verifyOtp: async function(req, resp, next) {
        let data = {};
        try {
            let rules = {
                verification_token: `required|exists:otp_verifications,token`,
                otp_code: `required|digits:6`
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            let otp_verification = null;
            await OtpVerification.findOne({ 'token': req.body.verification_token, 'type': "user-register" }).exec().then(function(details) {
                return otp_verification = details;
            }).catch(function(e) {
                return resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });
            })

            if (!otp_verification) {
                return resp.status(200).send({ status: 'error', message: 'The OTP token is invalid', data: data });
            }

            if (await helpers.getDateDifference(new Date(), new Date(otp_verification.updated_at), 'minutes') > 20) {
                return resp.status(200).json({ 'status': "error", 'message': 'The OTP has expired, please resend the OTP to continue', data: data });
            }

            if (req.body.otp_code != otp_verification.otp) {
                return resp.status(200).json({ 'status': "error", 'message': 'The OTP entered is invalid', data: data });
            }

            req.body.token = otp_verification.data.token;
            req.body.department_id = otp_verification.data.department_id;
            req.body.password = otp_verification.data.password;
            req.body.password_confirmation = otp_verification.data.password_confirmation;
            await self.submit(req, resp, next, true);
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },

    resendOtp: async function(req, resp, next) {
        let data = {};
        try {
            let rules = {
                verification_token: `required|exists:otp_verifications,token`,
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            let otp_verification = null;
            await OtpVerification.findOne({ 'token': req.body.verification_token, 'type': "user-register" }).exec().then(function(details) {
                return otp_verification = details;
            }).catch(function(e) {
                return resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });
            })

            if (!otp_verification) {
                return resp.status(200).send({ status: 'error', message: 'The OTP token is invalid', data: data });
            }

            const otp = await helpers.generateRandNumber(111111, 999999)
                // const otp = 111111
            const content = `${otp} is your one-time password for registration in CYTE. The otp is only valid for 20 min`

            if (helpers.sendSms(content, otp_verification.mobile)) {
                OtpVerification.updateOne({ token: req.body.verification_token }, { otp: otp, updated_at: Date.now() }, async function(e, details) {
                    if (e) return resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });

                    return resp.status(200).json({ 'status': "success", 'message': "The OTP has been resent successfully", data: data });
                })
            } else {
                return resp.status(200).send({ status: 'error', message: 'The otp cannot be sent. Please try again later', data: data });
            }
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    }
}

async function validateUserJoiningToken(token) {
    try {
        return new Promise(async(resolve, reject) => {
            let user_joining = null;
            await UserJoining.findOne({ 'token': token, 'used_at': null }, '').exec().then(function(details) {
                return user_joining = details;
            }).catch(function(e) {
                resolve({ 'status': false, 'message': e ? e.message : 'DB Error Occured' })
            })

            if (!user_joining) {
                resolve({ status: false, message: "The token may be expired or invalid. Please check your link sent to your email, or ask your manager to resend it." });
            }

            if (await helpers.getDateDifference(new Date(), new Date(user_joining.created_at), 'days') > 4) {
                resolve({ status: false, message: "The registration link has expired, please ask your manager to create a new link and resend it." });
            }

            resolve({ status: true, message: "Token validated succcessfully", user_joining: user_joining });
        });
    } catch (e) {
        resolve({ status: false, message: e ? e.message : 'Something went wrong' });
    }
}

async function validateUserDataForRege(key, value) {
    try {
        return new Promise(async(resolve, reject) => {
            await User.countDocuments({
                [key]: value
            }).exec().then(function(doc) {
                if (doc > 0) {
                    resolve({ 'status': false, 'message': `The ${key} is already taken. Please use different ${key}` })
                } else {
                    resolve({ status: true, message: "Success" });
                }
            }).catch(function(e) {
                resolve({ 'status': false, 'message': e ? e.message : 'DB Error Occured' });
            })
        });
    } catch (e) {
        resolve({ status: false, message: e ? e.message : 'Something went wrong' });
    }
}