module.exports = BCRYPT = {
    'saltrounds': 10
}