const Resource = require('resources.js');

class UserResource extends Resource {
    toArray() {
        let doc = {
            _id: this._id || null,
            token: this.token || null,
            role: this.role || null,
            data: this.data || null,
            used_at: this.used_at || null,
            created_at: this.created_at || null,
            updated_at: this.updated_at || null,
        }

        return doc;
    }
}

module.exports = UserResource;