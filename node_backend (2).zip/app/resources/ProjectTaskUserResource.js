const moment = require('moment');
const Resource = require('resources.js');

const ProjectTaskResource = require('./ProjectTaskResource');
const UserResource = require('./UserResource');

class ProjectTaskUserResource extends Resource {
    toArray() {
        let doc = {
            _id: this._id || null,
            task_id: this.task_id || null,
            user_id: this.user_id || null,
            status: this.status || null,
            created_at: this.created_at || null,
            updated_at: this.updated_at || null,
        }

        if (this.task !== undefined) {
            doc.task = new ProjectTaskResource(this.task).exec();
        }

        if (this.user !== undefined) {
            doc.user = new UserResource(this.user).exec();
        }

        return doc;
    }
}

module.exports = ProjectTaskUserResource;