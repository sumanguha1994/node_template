const mongoose = require('mongoose');
const mongoosePaginate = require('mongoose-paginate-v2');
const Schema = mongoose.Schema;

const UserJoiningSchema = new mongoose.Schema({
    token: {
        type: String,
        unique: true,
        required: true
    },
    role: {
        type: String,
        enum: ['manager', 'employee', 'contractor', 'supplier', 'safety_manager'],
        required: true
    },
    data: Schema.Types.Mixed,
    used_at: {
        type: Date,
        required: false,
        default: null
    },
    created_at: {
        type: Date,
        required: true,
        default: Date.now
    },
    updated_at: {
        type: Date,
        required: true,
        default: Date.now
    },
});

UserJoiningSchema.plugin(mongoosePaginate);

const UserJoining = mongoose.model('user_joinings', UserJoiningSchema);

module.exports = UserJoining;