const helpers = require('../../common/helpers');
const Division = require('../../models/Division');
const ProjectChannelUser = require('../../models/ProjectChannelUser');

const Project = require('../../models/Project');
const ProjectResource = require('../../resources/ProjectResource');
const ProjectChannelsResource = require('../../resources/ProjectChannelsResource');
const UserResource = require('../../resources/UserResource');
const User = require('../../models/User');
const mongoose = require('mongoose');

module.exports = {
    users: async function(req, resp) {
        let data = {};
        try {
            rules = {
                project_id: `required|mongoId|exists:projects,_id`,
                division_id: `required|mongoId|exists:divisions,_id`,
                pageno: `required|numeric`,
                // searchkey: `nullable`,
                length: `nullable`,
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            const options = {
                page: req.body.pageno,
                limit: req.body.length ? req.body.length : global.CONFIG.app.pagination.perpage,
                sort: { created_at: -1 },
            };

            var filter_option = {
                $match: {
                    $and: [{
                        'project_id': mongoose.Types.ObjectId(req.body.project_id),
                        'division_id': mongoose.Types.ObjectId(req.body.division_id),
                        'deleted_at': null
                    }]
                }
            };

            // if (req.body.searchkey) {
            //     filter_option.$match.$or = [
            //         { "name": { $regex: ".*" + req.body.searchkey + ".*" } },
            //         { "email": { $regex: ".*" + req.body.searchkey + ".*" } },
            //         { "mobile": { $regex: ".*" + req.body.searchkey + ".*" } },
            //     ];
            // }

            var modalAggregate = ProjectChannelUser.aggregate([
                filter_option,
                {
                    "$lookup": {
                        "from": "users",
                        "let": { "user_id": "$user_id" },
                        "pipeline": [{
                                "$match": {
                                    "$expr": { "$eq": ["$_id", "$$user_id"] },
                                }
                            }, {
                                $lookup: {
                                    from: 'departments',
                                    localField: 'department_id',
                                    foreignField: '_id',
                                    as: 'department'
                                },
                            },
                            {
                                $lookup: {
                                    from: 'divisions',
                                    localField: 'division_id',
                                    foreignField: '_id',
                                    as: 'division'
                                }
                            },
                            {
                                $addFields: {
                                    department: {
                                        $arrayElemAt: ["$department", 0]
                                    },
                                    division: {
                                        $arrayElemAt: ["$division", 0]
                                    },
                                },
                            },
                        ],
                        "as": "user"
                    }
                },
                {
                    $addFields: {
                        user: {
                            $arrayElemAt: ["$user", 0]
                        },
                    },
                },
            ]);

            ProjectChannelUser.aggregatePaginate(modalAggregate, options, function(e, rows) {
                if (e) return resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });

                // rows.docs = UserResource.collection(rows.docs);

                let docs = [];
                rows.docs.forEach(row => {
                    if (row.user) {
                        docs.push(new UserResource(row.user).exec());
                    }
                });

                rows.docs = docs;

                data.users = rows
                return resp.status(200).json({ status: 'success', 'message': 'Members fetched successfully', data: data });
            })
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },

    view: async function(req, resp) {
        let data = {};
        try {
            rules = {
                project_id: `required|mongoId|exists:projects,_id`,
                pageno: `required|numeric`,
                // searchkey: `nullable`,
                length: `nullable`,
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            const options = {
                page: req.body.pageno,
                limit: req.body.length ? req.body.length : global.CONFIG.app.pagination.perpage,
                sort: { created_at: -1 },
            };

            var filter_option = {
                $match: {
                    $and: [{ deleted_at: null }]
                }
            };

            if (req.body.searchkey) {
                filter_option.$match.$or = [
                    { "name": { $regex: ".*" + req.body.searchkey + ".*" } },
                    { "slug": { $regex: ".*" + req.body.searchkey + ".*" } },
                ];
            }

            var aggregate = Division.aggregate([
                filter_option,
                {
                    "$lookup": {
                        "from": "project_channel_users",
                        "let": { "division_id": "$_id" },
                        "pipeline": [{
                            "$match": {
                                "$expr": { "$eq": ["$division_id", "$$division_id"] },
                                "$and": [
                                    { 'deleted_at': null },
                                    { 'project_id': mongoose.Types.ObjectId(req.body.project_id) }
                                ]
                            }
                        }, {
                            "$lookup": {
                                "from": "users",
                                "let": { "user_id": "$user_id" },
                                "pipeline": [{
                                    "$match": {
                                        "$expr": { "$eq": ["$_id", "$$user_id"] },
                                        "$and": [{ 'deleted_at': null }]
                                    }
                                }, ],
                                "as": "user"
                            }
                        }, {
                            $addFields: {
                                user: {
                                    $arrayElemAt: ["$user", 0]
                                },
                            },
                        }],
                        "as": "project_channel_users"
                    }
                }
            ]);

            Division.aggregatePaginate(aggregate, options, function(e, rows) {
                if (e) return resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });

                rows.docs = ProjectChannelsResource.collection(rows.docs);

                data.channels = rows
                return resp.status(200).json({ status: 'success', 'message': 'Channels fetched successfully', data: data });
            })
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },

    assignUser: async function(req, resp) {
        let data = {};
        try {
            rules = {
                project_id: `required|mongoId|exists:projects,_id`,
                user_id: `required|mongoId|exists:users,_id`,
                division_id: `required|mongoId|exists:divisions,_id`,
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            let document = {
                'project_id': req.body.project_id,
                'division_id': req.body.division_id,
                'user_id': req.body.user_id,
                'deleted_at': null
            }

            let channelUserCount = 0;
            await ProjectChannelUser.countDocuments(document).exec().then(function(count) {
                return channelUserCount = count;
            })

            if (channelUserCount > 0) {
                return resp.status(200).send({ status: 'error', message: 'The user is already assigned to this channel', data: data });
            }

            await ProjectChannelUser.create(document, async function(e, details) {
                if (e) return resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });

                return resp.status(200).send({ status: 'success', message: 'The user assigned to the channel successfully', data: data });
            })
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }

    },

    removeUser: async function(req, resp) {
        let data = {};
        try {
            let rules = {
                project_id: `required|mongoId|exists:projects,_id`,
                user_id: `required|mongoId|exists:users,_id`,
                division_id: `required|mongoId|exists:divisions,_id`,
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            let document = {
                'project_id': req.body.project_id,
                'division_id': req.body.division_id,
                'user_id': req.body.user_id,
                'deleted_at': null
            }

            let channelUserCount = 0;
            await ProjectChannelUser.countDocuments(document).exec().then(function(count) {
                return channelUserCount = count;
            })

            if (!channelUserCount) {
                return resp.status(200).send({ status: 'error', message: 'The user is not assigned to this channel', data: data });
            }

            await ProjectChannelUser.updateOne(document, { deleted_at: Date.now() }, async function(e, details) {
                if (e) return resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });

                return resp.status(200).json({ 'status': "success", 'message': "The user removed from the channel successfully", data: data });
            })
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },

    fetchAssignes: async function(req, resp) {
        let data = {};
        try {
            let rules = {
                project_id: `required|mongoId|exists:projects,_id`,
                division_id: `required|mongoId|exists:divisions,_id`,
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            let usersIdsAssigned = []
            await ProjectChannelUser.find({ 'project_id': req.body.project_id, 'division_id': req.body.division_id, 'deleted_at': null }).select('user_id').exec().then(function(results) {
                results.forEach(element => {
                    usersIdsAssigned.push(element.user_id);
                });
            })

            data.users = [];
            await User.find({
                'role': { "$in": ['manager', 'employee', 'contractor', 'supplier', 'safety_manager'] },
                '_id': { "$nin": usersIdsAssigned },
                'status': "active",
                'division_id': req.body.division_id,
                'deleted_at': null
            }, '').sort({ 'name': 1 }).exec().then(function(users) {
                return data.users = UserResource.collection(users);
            });

            return resp.status(200).send({ status: 'success', message: "Success", data: data });
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }

    }
}