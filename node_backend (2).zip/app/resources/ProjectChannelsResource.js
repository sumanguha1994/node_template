const Resource = require('resources.js');
const UserResource = require('./UserResource');

class ProjectChannelsResource extends Resource {
    toArray() {
        let doc = {
            division_id: this._id || null,
            division_name: this.name || null,
            division_slug: this.slug || null,
        }

        doc.project_channel_users = [];
        if (this.project_channel_users !== undefined && Array.isArray(this.project_channel_users)) {
            this.project_channel_users.forEach(element => {
                doc.project_channel_users.push(new UserResource(element.user).exec());
            });
        }

        return doc;
    }
}

module.exports = ProjectChannelsResource;