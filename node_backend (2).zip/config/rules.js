module.exports = RULES = {
    'password': {
        'minlength': 8,
        'maxlength': 20,
    }
}