const Resource = require('resources.js');
const UserResource = require('./UserResource');
const ProjectResource = require('./ProjectResource');
const DivisionResource = require('./DivisionResource');
const ProjectChannelPostReactResource = require('./ProjectChannelPostReactResource');
const ProjectChannelPostCommentResource = require('./ProjectChannelPostCommentResource');

class ProjectChannelPostResource extends Resource {
    toArray() {
        let doc = {
            _id: this._id || null,
            project_id: this.project_id || null,
            division_id: this.division_id || null,
            user_id: this.user_id || null,
            type: this.type || null,
            description: this.description || null,
            uploads: this.uploads || [],
            status: this.status || null,
            created_at: this.created_at || null,
            updated_at: this.updated_at || null,
        }

        doc.uploads = doc.uploads.map(obj => ({
            ...obj,
            filepath: global.CONFIG.app.url + '/public/uploads/projects/posts/' + obj.file
        }));

        if (this.user !== undefined) {
            doc.user = new UserResource(this.user).exec();
        }

        if (this.project !== undefined) {
            doc.project = new ProjectResource(this.project).exec();
        }

        if (this.division !== undefined) {
            doc.division = new DivisionResource(this.division).exec();
        }

        if (this.RESP_SETTINGS?.reacts_count === true) {
            doc.reacts_count = {
                total: (this.reacts ?? []).length,
            }

            let availreacts = ['like', 'fire', 'rock', 'support']
            availreacts.forEach(element => {
                doc.reacts_count[element] = this.reacts.filter((obj) => {
                    return obj.type == element
                }).length
            });
        }

        if (this.RESP_SETTINGS?.recent_reacts == true && this.recent_reacts !== undefined) {
            doc.recent_reacts = ProjectChannelPostReactResource.collection(this.recent_reacts);
        }

        if (this.RESP_SETTINGS?.comments_count === true) {
            doc.comments_count = (this.comments ?? []).length
        }

        if (this.RESP_SETTINGS?.recent_comments == true && this.recent_comments !== undefined) {
            doc.recent_comments = ProjectChannelPostCommentResource.collection(this.recent_comments);
        }

        if (this.RESP_SETTINGS?.comments == true && this.comments !== undefined) {
            doc.comments = ProjectChannelPostCommentResource.collection(this.comments);
        }

        if (this.RESP_SETTINGS?.user_react == true) {
            doc.user_react = this.user_react?.type ?? null;
        }

        return doc;
    }
}

module.exports = ProjectChannelPostResource;