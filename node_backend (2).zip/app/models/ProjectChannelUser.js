const mongoose = require('mongoose');
const mongoosePaginate = require('mongoose-paginate-v2');
const mongooseAggregatePaginate = require('mongoose-aggregate-paginate-v2');

const Schema = mongoose.Schema;

const ProjectChannelUserSchema = new mongoose.Schema({
    project_id: {
        type: mongoose.Types.ObjectId,
        required: true
    },
    division_id: {
        type: mongoose.Types.ObjectId,
        required: true
    },
    user_id: {
        type: mongoose.Types.ObjectId,
        required: true
    },
    created_at: {
        type: Date,
        required: true,
        default: Date.now
    },
    updated_at: {
        type: Date,
        required: true,
        default: Date.now
    },
    deleted_at: {
        type: Date,
        required: false,
        default: null
    },
});

ProjectChannelUserSchema.plugin(mongoosePaginate);
ProjectChannelUserSchema.plugin(mongooseAggregatePaginate);

const ProjectChannelUser = mongoose.model('project_channel_users', ProjectChannelUserSchema);

module.exports = ProjectChannelUser;