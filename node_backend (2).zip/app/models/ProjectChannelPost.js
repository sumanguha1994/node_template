const mongoose = require('mongoose');
const mongoosePaginate = require('mongoose-paginate-v2');
const mongooseAggregatePaginate = require('mongoose-aggregate-paginate-v2');

const Schema = mongoose.Schema;

const UploadSchema = new Schema({
    file: {
        type: String,
        required: true,
    }
});


const ProjectChannelPostSchema = new mongoose.Schema({
    project_id: {
        type: mongoose.Types.ObjectId,
        required: true
    },
    division_id: {
        type: mongoose.Types.ObjectId,
        required: false,
        default: null,
    },
    user_id: {
        type: mongoose.Types.ObjectId,
        required: true
    },
    type: {
        type: String,
        enum: ["post", "thread"],
        required: false,
        default: "post"
    },
    description: {
        type: String,
        required: true
    },
    uploads: [UploadSchema],
    status: {
        type: String,
        enum: ["active", "inactive"],
        required: true,
        default: "active"
    },
    created_at: {
        type: Date,
        required: true,
        default: Date.now
    },
    updated_at: {
        type: Date,
        required: true,
        default: Date.now
    },
    deleted_at: {
        type: Date,
        required: false,
        default: null
    },
});

ProjectChannelPostSchema.plugin(mongoosePaginate);
ProjectChannelPostSchema.plugin(mongooseAggregatePaginate);

const ProjectChannelPost = mongoose.model('project_channel_posts', ProjectChannelPostSchema);

module.exports = ProjectChannelPost;