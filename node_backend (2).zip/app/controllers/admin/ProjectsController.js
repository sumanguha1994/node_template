const helpers = require('../../common/helpers');

const Project = require('../../models/Project');
const Division = require('../../models/Division');
const ProjectResource = require('../../resources/ProjectResource');
const DivisionResource = require('../../resources/DivisionResource');

module.exports = {
    view: async function(req, resp) {
        let data = {};
        try {
            rules = {
                pageno: `required|numeric`,
                searchkey: `nullable`,
                length: `nullable`,
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            const options = {
                page: req.body.pageno,
                limit: req.body.length ? req.body.length : global.CONFIG.app.pagination.perpage,
                sort: { created_at: -1 },
            };

            var filter_option = {
                $match: {
                    $and: [{ deleted_at: null }]
                }
            };

            if (req.body.searchkey) {
                filter_option.$match.$or = [
                    { "name": { $regex: ".*" + req.body.searchkey + ".*" } },
                    { "slug": { $regex: ".*" + req.body.searchkey + ".*" } },
                    { "location": { $regex: ".*" + req.body.searchkey + ".*" } },
                ];
            }

            var projectAggregrate = Project.aggregate([
                filter_option,
            ]);

            Project.aggregatePaginate(projectAggregrate, options, function(e, rows) {
                if (e) return resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });

                rows.docs = ProjectResource.collection(rows.docs);

                data.projects = rows
                return resp.status(200).json({ status: 'success', 'message': 'Members fetched successfully', data: data });
            })
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },

    add: async function(req, resp) {
        let data = {};
        try {
            let rules = {
                name: `required`,
                location: `required`,
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            let document = {
                'name': req.body.name,
                'slug': await helpers.generateCollectionSlug(Project, req.body.name, 'slug'),
                'location': req.body.location,
                'created_by': req.auth.id
            }

            if (req.files && req.files.image !== undefined) {
                const uploadImage = await helpers.uploadFile(req.files.image, 'projects');
                if (uploadImage.status == false) {
                    return resp.status(200).json({ 'status': "error", 'message': "File upload error : " + uploadImage.message, data: data });
                }

                document.image = uploadImage.filename;
            }

            Project.create(document, async function(e, details) {
                if (e) return resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });

                data.project = new ProjectResource(details).exec();

                return resp.status(200).json({ 'status': "success", 'message': "Project created successfully", data: data });
            })
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },

    edit: async function(req, resp) {
        let data = {};
        try {
            let rules = {
                project_id: `required|mongoId|exists:projects,_id`,
                name: `required`,
                location: `required`,
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            let project_details = await Project.findOne({ '_id': req.body.project_id }).exec().then(function(row) {
                return row;
            }).catch(function(e) {
                resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });
                process.exit(1);
            })

            if (!project_details) {
                return resp.status(404).send({ status: 'error', message: 'Project Not Found', data: data });
            }

            var document = {
                name: req.body.name,
                slug: await helpers.generateCollectionSlug(Project, req.body.name, 'slug', req.body.project_id),
                location: req.body.location,
                updated_at: Date.now(),
            };

            if (req.files && req.files.image !== undefined) {
                const uploadImage = await helpers.uploadFile(req.files.image, 'projects');
                if (uploadImage.status == false) {
                    return resp.status(200).json({ 'status': "error", 'message': "File upload error : " + uploadImage.message, data: data });
                }

                if (project_details.image) {
                    await helpers.deleteFile(project_details.image, 'projects');
                }

                document.image = uploadImage.filename;
            }

            await Project.updateOne({ '_id': req.body.project_id }, document, async function(err, details) {
                if (err) {
                    return resp.status(200).send({ status: 'error', message: err ? err.message : 'DB Error Occured', data: data });
                }

                data.project = null;
                await Project.findOne({ _id: req.body.project_id }, '', ).exec().then(function(project) {
                    return data.project = new ProjectResource(project).exec();
                })

                return resp.status(200).send({ status: 'success', message: 'Project updated successfully', data: data });
            })
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },

    changeStatus: async function(req, resp) {
        let data = {};
        try {
            rules = {
                project_id: `required|mongoId|exists:projects,_id`,
                status: `required|in:active,inactive`,
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            var document = {
                status: req.body.status,
                updated_at: Date.now(),
            };

            await Project.updateOne({ '_id': req.body.project_id }, document, async function(err, details) {
                if (err) {
                    return resp.status(200).send({ status: 'error', message: err ? err.message : 'DB Error Occured', data: data });
                }

                data.project = null;
                await Project.findOne({ _id: req.body.project_id }, '', ).exec().then(function(project) {
                    return data.project = new ProjectResource(project).exec();
                });

                return resp.status(200).send({
                    status: 'success',
                    message: (data.project.status == 'active') ? "Project activated successfully" : "Project deactivated successfully",
                    data: data
                });
            })
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },

    delete: async function(req, resp) {
        let data = {};
        try {
            rules = {
                project_id: `required|mongoId|exists:projects,_id`,
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            var document = {
                deleted_at: Date.now(),
            };

            await Project.updateOne({ '_id': req.body.project_id }, document, async function(err, details) {
                if (err) {
                    return resp.status(200).send({ status: 'error', message: err ? err.message : 'DB Error Occured', data: data });
                }

                return resp.status(200).send({ status: 'success', message: "Project deleted successfully", data: data });
            })
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },

    details: async function(req, resp) {
        let data = {};
        try {
            rules = {
                project_id: `required|mongoId|exists:projects,_id`,
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            data.master = { divisions: [] };
            await Division.find({ 'status': "active", 'deleted_at': null }, '').sort({ 'name': 1 }).exec().then(function(divisions) {
                return data.master.divisions = DivisionResource.collection(divisions);
            });

            data.project = null
            await Project.findOne({ '_id': req.body.project_id, 'deleted_at': null }).exec().then(function(details) {
                if (details) {
                    return data.project = new ProjectResource(details).exec();
                }
            })

            if (!data.project) {
                return resp.status(200).send({ status: 'error', message: 'Project not found', data: data });
            }

            return resp.status(200).send({ status: 'success', message: "Success", data: data });
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    }
}