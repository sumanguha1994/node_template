const helpers = require('../../common/helpers');
const { sendMail } = require('../../common/mailer');

const User = require('../../models/User');
const UserJoining = require('../../models/UserJoining');
const Department = require('../../models/Department');
const Division = require('../../models/Division');

const UserResource = require('../../resources/UserResource');
const DepartmentResource = require('../../resources/DepartmentResource');
const DivisionResource = require('../../resources/DivisionResource');

module.exports = {
    view: async function (req, resp) {
        let data = {};
        try {
            rules = {
                role: `required|in:manager,employee,contractor,supplier,safety_manager`,
                pageno: `required|numeric`,
                searchkey: `nullable`,
                length: `nullable`,
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            const options = {
                page: req.body.pageno,
                limit: req.body.length ? req.body.length : global.CONFIG.app.pagination.perpage,
                sort: { created_at: -1 },
            };

            var filter_option = {
                $match: {
                    $and: [{ 'role': req.body.role, deleted_at: null }]
                }
            };

            if (req.body.searchkey) {
                filter_option.$match.$or = [
                    { "name": { $regex: ".*" + req.body.searchkey + ".*" } },
                    { "email": { $regex: ".*" + req.body.searchkey + ".*" } },
                    { "mobile": { $regex: ".*" + req.body.searchkey + ".*" } },
                ];
            }

            var userAggregrate = User.aggregate([
                filter_option,
                {
                    $lookup: {
                        from: 'departments',
                        localField: 'department_id',
                        foreignField: '_id',
                        as: 'department'
                    },
                },
                {
                    $lookup: {
                        from: 'divisions',
                        localField: 'division_id',
                        foreignField: '_id',
                        as: 'division'
                    }
                },
                {
                    $addFields: {
                        department: {
                            $arrayElemAt: ["$department", 0]
                        },
                        division: {
                            $arrayElemAt: ["$division", 0]
                        },
                    },
                },
            ]);

            User.aggregatePaginate(userAggregrate, options, function (e, rows) {
                if (e) return resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });

                rows.docs = UserResource.collection(rows.docs);

                data.users = rows
                return resp.status(200).json({ status: 'success', 'message': 'Members fetched successfully', data: data });
            })
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },

    add: async function (req, resp) {
        let data = {};
        try {
            rules = {
                role: `required|in:manager,employee,contractor,supplier,safety_manager`,
                name: `required`,
                email: `required|email|unique:users,email`,
                mobile: `required|phoneNumber|unique:users,mobile`,
                department_id: `required|mongoId|exists:departments,_id`,
                division_id: `required|mongoId|exists:divisions,_id`,
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            const password = await helpers.generateRandomString(10);

            let document = {
                'role': req.body.role,
                'name': req.body.name,
                'email': req.body.email,
                'mobile': req.body.mobile,
                'department_id': req.body.department_id,
                'division_id': req.body.division_id,
                'password': await helpers.bcryptMake(password),
            }

            User.create(document, async function (e, details) {
                if (e) return resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });

                data.user = new UserResource(details).exec();
                data.logincredentials = {
                    'email': details.email,
                    'mobile': details.mobile,
                    'password': password
                };

                return resp.status(200).json({ 'status': "success", 'message': "Member account created successfully", data: data });
            })
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },

    edit: async function (req, resp) {
        let data = {};
        try {
            switch (req.body.operation) {
                case 'basicdetails':
                    rules = {
                        user_id: `required|mongoId|exists:users,_id`,
                        name: `required`,
                        email: `required|email|unique:users,email,` + req.body.user_id,
                        mobile: `required|phoneNumber|unique:users,mobile,` + req.body.user_id,
                        department_id: `required|mongoId|exists:departments,_id`,
                        division_id: `required|mongoId|exists:divisions,_id`,
                    };
                    break;

                case 'password':
                    rules = {
                        user_id: `required|mongoId|exists:users,_id`,
                        password: `required|length:${global.CONFIG.rules.password.maxlength},${global.CONFIG.rules.password.minlength}`,
                        password_confirmation: `required|length:${global.CONFIG.rules.password.maxlength},${global.CONFIG.rules.password.minlength}|same:password`,
                    };
                    break;

                case 'profilepicture':
                    rules = {};
                    break;

                default:
                    return resp.status(404).send({ status: 'error', message: 'Invalid Request Received', data: data });
            }

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            let user_details = await User.findOne({ '_id': req.body.user_id }).exec().then(function (row) {
                return row;
            }).catch(function (e) {
                resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });
                process.exit(1);
            })

            if (!user_details) {
                return resp.status(404).send({ status: 'error', message: 'User Not Found', data: data });
            }

            if (!['manager', 'employee', 'contractor', 'supplier', 'safety_manager'].includes(user_details.role)) {
                return resp.status(200).send({ status: 'error', message: 'Unauthorized Action', data: data });
            }

            let successmsg = 'Member account updated successfully';
            let action = false;
            switch (req.body.operation) {
                case 'basicdetails':
                    var document = {
                        name: req.body.name,
                        email: req.body.email,
                        mobile: req.body.mobile,
                        department_id: req.body.department_id,
                        division_id: req.body.division_id,
                        updated_at: Date.now(),
                    };

                    await User.updateOne({ '_id': req.body.user_id }, document, function (err, details) {
                        if (err) {
                            resp.status(200).send({ status: 'error', message: err ? err.message : 'DB Error Occured', data: data });
                            process.exit(1);
                        }

                        action = true;
                    })
                    break;

                case 'password':
                    var document = {
                        password: await helpers.bcryptMake(req.body.password),
                    };

                    await User.updateOne({ '_id': req.body.user_id }, document, function (err, details) {
                        if (err) {
                            resp.status(200).send({ status: 'error', message: err ? err.message : 'DB Error Occured', data: data });
                            process.exit(1);
                        }

                        action = true;
                        successmsg = 'Member password changed successfully';
                    })
                    break;

                case 'profilepicture':
                    var document = {};

                    if (req.files && req.files.image !== undefined) {
                        const uploadImage = await helpers.uploadFile(req.files.image, 'users/profile', ['JPG', 'JPEG', 'PNG', 'jpg', 'jpeg', 'png']);
                        if (uploadImage.status == false) {
                            return resp.status(200).json({ 'status': "error", 'message': "File upload error : " + uploadImage.message, data: data });
                        }

                        if (user_details.image) {
                            await helpers.deleteFile(user_details.image, 'users/profile');
                        }

                        document.image = uploadImage.filename;
                    } else {
                        return resp.status(200).json({ 'status': "error", 'message': "Please select a image to upload.", data: data });
                    }


                    await User.updateOne({ '_id': user_details._id }, document, function (err, details) {
                        if (err) {
                            resp.status(200).send({ status: 'error', message: err ? err.message : 'DB Error Occured', data: data });
                            process.exit(1);
                        }

                        action = true;
                        successmsg = "Profile Picture Updated Successfully";
                    })
                    break;

                default:
                    return resp.status(404).send({ status: 'error', message: 'Invalid Request Received', data: data });
            }

            if (action) {
                data.user = null;
                await User.findOne({ _id: req.body.user_id }, '',).exec().then(function (user) {
                    return data.user = new UserResource(user).exec();
                })

                return resp.status(200).send({ status: 'success', message: successmsg ? successmsg : 'Member account updated successfully', data: data });
            } else {
                return resp.status(400).send({ status: 'error', message: 'Invalid Request Received', data: data });
            }
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },

    changeStatus: async function (req, resp) {
        let data = {};
        try {
            rules = {
                user_id: `required|mongoId|exists:users,_id`,
                status: `required|in:active,inactive`,
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            let user_details = await User.findOne({ '_id': req.body.user_id }).exec().then(function (row) {
                return row;
            }).catch(function (e) {
                resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });
                process.exit(1);
            })

            if (!user_details) {
                return resp.status(404).send({ status: 'error', message: 'User Not Found', data: data });
            }

            if (!['manager', 'employee', 'contractor', 'supplier', 'safety_manager'].includes(user_details.role)) {
                return resp.status(200).send({ status: 'error', message: 'Unauthorized Action', data: data });
            }

            var document = {
                status: req.body.status,
                updated_at: Date.now(),
            };

            await User.updateOne({ '_id': req.body.user_id }, document, async function (err, details) {
                if (err) {
                    return resp.status(200).send({ status: 'error', message: err ? err.message : 'DB Error Occured', data: data });
                }

                data.user = null;
                await User.findOne({ _id: req.body.user_id }, '',).exec().then(function (user) {
                    return data.user = new UserResource(user).exec();
                })

                let rspmsg = "Member account deactivated successfully";
                if (data.user.status == 'active') {
                    rspmsg = "Member account activated successfully";
                }

                return resp.status(200).send({ status: 'success', message: rspmsg, data: data });
            })
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },

    createRegistrationLink: async function (req, resp) {
        let data = {};
        try {
            rules = {
                role: `required|in:manager,employee,contractor,supplier,safety_manager`,
                name: `required`,
                email: `required|email|unique:users,email`,
                mobile: `required|phoneNumber|unique:users,mobile`,
                department_id: `required|mongoId|exists:departments,_id`,
                division_id: `required|mongoId|exists:divisions,_id`,
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            const token = await helpers.generateRandomString(60);

            let document = {
                'token': token,
                'role': req.body.role,
                'data': {
                    'name': req.body.name,
                    'email': req.body.email,
                    'mobile': req.body.mobile,
                    'department_id': req.body.department_id,
                    'division_id': req.body.division_id,
                }
            }

            const send_email = await sendMail({
                to: document.data.email,
                subject: "CYTE - REGISTRATION INVITAION",
                type: "member-registration-link",
                data: {
                    user_name: document.data.name,
                    registration_token: document.token,
                }
            })

            await UserJoining.deleteMany({ $or: [{ 'data.email': document.data.email }, { 'data.mobile': document.data.mobile }] }).exec();

            UserJoining.create(document, async function (e, details) {
                if (e) return resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });

                data.registration_link = global.CONFIG.app.frontend_url + '/register?token=' + details.token;

                return resp.status(200).json({ 'status': "success", 'message': "Registration link sent successfully", data: data });
            })
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }

    },

    fetchMaster: async function (req, resp) {
        let data = {};
        try {
            data.departments = [];
            await Department.find({ 'status': "active", 'deleted_at': null }, '').sort({ 'name': 1 }).exec().then(function (departments) {
                return data.departments = DepartmentResource.collection(departments);
            });

            data.divisions = [];
            await Division.find({ 'status': "active", 'deleted_at': null }, '').sort({ 'name': 1 }).exec().then(function (divisions) {
                return data.divisions = DivisionResource.collection(divisions);
            });

            return resp.status(200).send({ status: 'success', message: "Success", data: data });
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    }
}