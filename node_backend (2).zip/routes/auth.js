const express = require('express');
const router = express.Router();

// Importing Middleware
const AuthMiddleware = require('../app/middleware/AuthMiddleware');

// Importing Controllers
const AdminAuthController = require('../app/controllers/auth/AdminAuthController');
const RegisterController = require('../app/controllers/auth/RegisterController');
const LoginController = require('../app/controllers/auth/LoginController');

router.post('/admin/login', AdminAuthController.login);
router.post('/admin/getaccount', AuthMiddleware.checkAuth, AuthMiddleware.checkRole(['superadmin']), AdminAuthController.getAccountDetails);

router.post('/register/master', RegisterController.fetchMaster);
router.post('/register/submit', RegisterController.submit);
router.post('/register/otp/verify', RegisterController.verifyOtp);
router.post('/register/otp/resend', RegisterController.resendOtp);

router.post('/login/submit', LoginController.submit);
router.post('/login/otp/verify', LoginController.verifyOtp);
router.post('/login/otp/resend', LoginController.resendOtp);

module.exports = router;