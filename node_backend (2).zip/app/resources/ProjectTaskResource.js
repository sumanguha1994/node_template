const moment = require('moment');
const Resource = require('resources.js');
const DivisionResource = require('./DivisionResource');
const ProjectResource = require('./ProjectResource');

class ProjectTaskResource extends Resource {
    toArray() {
        let doc = {
            _id: this._id || null,
            project_id: this.project_id || null,
            division_id: this.division_id || null,
            end_date: this.end_date ? moment(this.end_date).format("YYYY-MM-DD") : null,
            priority: this.priority || null,
            description: this.description || null,
            status: this.status || null,
            created_at: this.created_at || null,
            updated_at: this.updated_at || null,
        }

        if (this.project !== undefined) {
            doc.project = new ProjectResource(this.project).exec();
        }

        if (this.division !== undefined) {
            doc.division = new DivisionResource(this.division).exec();
        }

        return doc;
    }
}

module.exports = ProjectTaskResource;