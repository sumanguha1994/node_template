const Resource = require('resources.js');

class DivisionResource extends Resource {
    toArray() {
        let doc = {
            _id: this._id || null,
            name: this.name || null,
            slug: this.slug || null,
            status: this.status || null,
            created_at: this.created_at || null,
            updated_at: this.updated_at || null,
        }

        return doc;
    }
}

module.exports = DivisionResource;