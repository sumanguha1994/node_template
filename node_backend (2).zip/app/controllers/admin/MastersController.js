const helpers = require('../../common/helpers');
const Department = require('../../models/Department');
const Division = require('../../models/Division');
const DepartmentResource = require('../../resources/DepartmentResource');
const DivisionResource = require('../../resources/DivisionResource');

module.exports = {
    view: async function(req, resp) {
        let data = {};
        try {
            rules = {
                pageno: `required|numeric`,
                searchkey: `nullable`,
                length: `nullable`,
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            let options = {
                page: req.body.pageno,
                limit: req.body.length ? req.body.length : global.CONFIG.app.pagination.perpage,
                sort: { created_at: -1 },
            };

            let filter_option = {
                deleted_at: null,
            };

            switch (req.params.type) {
                case 'department':
                    if (req.body.searchkey) {
                        filter_option.$or = [
                            { "name": { $regex: ".*" + req.body.searchkey + ".*" } },
                            { "slug": { $regex: ".*" + req.body.searchkey + ".*" } },
                        ];
                    }

                    Department.paginate(filter_option, options, function(e, rows) {
                        if (e) return resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });

                        rows.docs = DepartmentResource.collection(rows.docs);

                        data.departments = rows
                        return resp.status(200).json({ status: 'success', 'message': 'Departments fetched successfully', data: data });
                    })
                    break;

                case 'division':
                    if (req.body.searchkey) {
                        filter_option.$or = [
                            { "name": { $regex: ".*" + req.body.searchkey + ".*" } },
                            { "slug": { $regex: ".*" + req.body.searchkey + ".*" } },
                        ];
                    }

                    Division.paginate(filter_option, options, function(e, rows) {
                        if (e) return resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });

                        rows.docs = DivisionResource.collection(rows.docs);

                        data.divisions = rows
                        return resp.status(200).json({ status: 'success', 'message': 'Divisions fetched successfully', data: data });
                    })
                    break;

                default:
                    return resp.status(404).send({ status: 'error', message: 'Invalid Request Received', data: data });
            }
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },

    add: async function(req, resp) {
        let data = {};
        try {
            switch (req.params.type) {
                case 'department':
                    rules = {
                        name: `required|unique:departments,name`,
                    };
                    break;

                case 'division':
                    rules = {
                        name: `required|unique:divisions,name`,
                    };
                    break;

                default:
                    return resp.status(404).send({ status: 'error', message: 'Invalid Request Received', data: data });
            }

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            var document = {};

            switch (req.params.type) {
                case 'department':
                    document = {
                        'name': req.body.name,
                        'slug': await helpers.generateCollectionSlug(Department, req.body.name, 'slug')
                    }

                    Department.create(document, async function(e, details) {
                        if (e) return resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });

                        data.department = new DepartmentResource(details).exec();
                        return resp.status(200).json({ 'status': "success", 'message': "Department created successfully", data: data });
                    })
                    break;

                case 'division':
                    document = {
                        'name': req.body.name,
                        'slug': await helpers.generateCollectionSlug(Division, req.body.name, 'slug')
                    }

                    Division.create(document, async function(e, details) {
                        if (e) return resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });

                        data.division = new DivisionResource(details).exec();
                        return resp.status(200).json({ 'status': "success", 'message': "Division created successfully", data: data });
                    })
                    break;

                default:
                    return resp.status(404).send({ status: 'error', message: 'Invalid Request Received', data: data });
            }
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },

    edit: async function(req, resp) {
        let data = {};
        try {
            switch (req.params.type) {
                case 'department':
                    rules = {
                        department_id: `required|mongoId|exists:departments,_id`,
                        name: `required|unique:departments,name,` + req.body.department_id,
                    };
                    break;

                case 'division':
                    rules = {
                        division_id: `required|mongoId|exists:divisions,_id`,
                        name: `required|unique:divisions,name,` + req.body.division_id,
                    };
                    break;

                default:
                    return resp.status(404).send({ status: 'error', message: 'Invalid Request Received', data: data });
            }

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            var document = {};

            switch (req.params.type) {
                case 'department':
                    document = {
                        name: req.body.name,
                        slug: await helpers.generateCollectionSlug(Department, req.body.name, 'slug', req.body.department_id),
                        updated_at: Date.now(),
                    };

                    await Department.updateOne({ '_id': req.body.department_id }, document, function(err, details) {
                        if (err) {
                            resp.status(200).send({ status: 'error', message: err ? err.message : 'DB Error Occured', data: data });
                            process.exit(1);
                        }
                    });

                    data.department = null;
                    await Department.findOne({ _id: req.body.department_id }, '', ).exec().then(function(department) {
                        return data.department = new DepartmentResource(department).exec();
                    })

                    return resp.status(200).send({ status: 'success', message: 'Department updated successfully', data: data });
                    break;

                case 'division':
                    document = {
                        name: req.body.name,
                        slug: await helpers.generateCollectionSlug(Division, req.body.name, 'slug', req.body.division_id),
                        updated_at: Date.now(),
                    };

                    await Division.updateOne({ '_id': req.body.division_id }, document, function(err, details) {
                        if (err) {
                            resp.status(200).send({ status: 'error', message: err ? err.message : 'DB Error Occured', data: data });
                            process.exit(1);
                        }
                    });

                    data.division = null;
                    await Division.findOne({ _id: req.body.division_id }, '', ).exec().then(function(division) {
                        return data.division = new DivisionResource(division).exec();
                    })

                    return resp.status(200).send({ status: 'success', message: 'Division updated successfully', data: data });
                    break;

                default:
                    return resp.status(404).send({ status: 'error', message: 'Invalid Request Received', data: data });
            }
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },

    changeStatus: async function(req, resp) {
        let data = {};
        try {
            switch (req.params.type) {
                case 'department':
                    rules = {
                        department_id: `required|mongoId|exists:departments,_id`,
                        status: `required|in:active,inactive`,
                    };
                    break;

                case 'division':
                    rules = {
                        division_id: `required|mongoId|exists:divisions,_id`,
                        status: `required|in:active,inactive`,
                    };
                    break;

                default:
                    return resp.status(404).send({ status: 'error', message: 'Invalid Request Received', data: data });
            }

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            let document = {
                status: req.body.status,
                updated_at: Date.now(),
            };

            switch (req.params.type) {
                case 'department':
                    await Department.updateOne({ '_id': req.body.department_id }, document, async function(err, details) {
                        if (err) {
                            return resp.status(200).send({ status: 'error', message: err ? err.message : 'DB Error Occured', data: data });
                        }

                        data.department = null;
                        await Department.findOne({ _id: req.body.department_id }, '', ).exec().then(function(department) {
                            return data.department = new DepartmentResource(department).exec();
                        })

                        return resp.status(200).send({
                            status: 'success',
                            message: (data.department.status == 'active') ? "Department activated successfully" : "Department deactivated successfully",
                            data: data
                        });
                    })
                    break;

                case 'division':
                    await Division.updateOne({ '_id': req.body.division_id }, document, async function(err, details) {
                        if (err) {
                            return resp.status(200).send({ status: 'error', message: err ? err.message : 'DB Error Occured', data: data });
                        }

                        data.division = null;
                        await Division.findOne({ _id: req.body.division_id }, '', ).exec().then(function(division) {
                            return data.division = new DivisionResource(division).exec();
                        })

                        return resp.status(200).send({
                            status: 'success',
                            message: (data.division.status == 'active') ? "Division activated successfully" : "Division deactivated successfully",
                            data: data
                        });
                    })
                    break;


                default:
                    return resp.status(404).send({ status: 'error', message: 'Invalid Request Received', data: data });
            }
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },

    delete: async function(req, resp) {
        let data = {};
        try {
            switch (req.params.type) {
                case 'department':
                    rules = {
                        department_id: `required|mongoId|exists:departments,_id`,
                    };
                    break;

                case 'division':
                    rules = {
                        division_id: `required|mongoId|exists:divisions,_id`,
                    };
                    break;

                default:
                    return resp.status(404).send({ status: 'error', message: 'Invalid Request Received', data: data });
            }

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            let document = {
                deleted_at: Date.now(),
            };

            switch (req.params.type) {
                case 'department':
                    await Department.updateOne({ '_id': req.body.department_id }, document, async function(err, details) {
                        if (err) {
                            return resp.status(200).send({ status: 'error', message: err ? err.message : 'DB Error Occured', data: data });
                        }

                        return resp.status(200).send({
                            status: 'success',
                            message: "Department deleted successfully",
                            data: data
                        });
                    })
                    break;

                case 'division':
                    await Division.updateOne({ '_id': req.body.division_id }, document, async function(err, details) {
                        if (err) {
                            return resp.status(200).send({ status: 'error', message: err ? err.message : 'DB Error Occured', data: data });
                        }

                        return resp.status(200).send({
                            status: 'success',
                            message: "Division deleted successfully",
                            data: data
                        });
                    })
                    break;

                default:
                    return resp.status(404).send({ status: 'error', message: 'Invalid Request Received', data: data });
            }
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },
}