const helpers = require('../../common/helpers');
const User = require('../../models/User');
const OtpVerification = require('../../models/OtpVerification');

const UserResource = require('../../resources/UserResource');

const self = module.exports = {
    submit: async function(req, resp, next, otp_verification = false) {
        let data = {};
        try {
            let rules = {
                email: `required|email`,
                password: `required|length:${global.CONFIG.rules.password.maxlength},${global.CONFIG.rules.password.minlength}`,
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            let user = null;
            await User.findOne({ 'email': req.body.email, 'role': { $in: ["manager", "employee", "contractor", "supplier", "safety_manager"] }, 'deleted_at': null }, '').exec().then(function(details) {
                return user = details;
            }).catch(function(e) {
                resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });
                process.exit(1);
            })

            if (!user) {
                return resp.status(200).json({ status: 'error', message: 'The email you entered is invalid', data: data });
            }

            if (user.status != "active") {
                return resp.status(200).json({ status: 'error', message: 'The account has been blocked', data: data });
            }

            if (!await helpers.bcryptCheck(req.body.password, user.password)) {
                return resp.status(200).json({ status: 'error', message: 'The password you entered is invalid', data: data });
            }

            if (!user.mobile_verified_at && !otp_verification) {
                // const otp = await helpers.generateRandNumber(111111, 999999)
                const otp = 111111
                const content = `${otp} is your one-time password for verifying your account in CYTE. The otp is only valid for 20 min`

                if (helpers.sendSms(content, user.mobile)) {
                    let otp_document = {
                        'email': user.email,
                        'mobile': user.mobile,
                        'otp': otp,
                        'type': 'user-login',
                        'token': await helpers.generateRandomString(60),
                        'data': {
                            'email': req.body.email,
                            'password': req.body.password,
                            'user_id': user._id,
                        },
                    }

                    await OtpVerification.deleteMany({ 'email': user.email, 'mobile': user.mobile, 'type': 'user-login' }).exec();

                    await OtpVerification.create(otp_document, async function(e, details) {
                        if (e) return resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });

                        return resp.status(200).json({
                            'status': "otpverification",
                            'message': "An OTP has been sent to your mobile number",
                            data: {
                                token: details.token,
                                mobile: details.mobile,
                                email: details.email
                            }
                        });
                    })

                    return;
                } else {
                    return resp.status(200).send({ status: 'error', message: 'The otp cannot be sent. Please try again later', data: data });
                }
            }

            data.user = new UserResource(user).exec();
            data.token = await helpers.generateJwtToken({ 'user_id': user._id, 'email': user.email, 'role': user.role });
            return resp.status(200).send({ status: 'success', message: "Logedin Successfully", data: data });
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },

    verifyOtp: async function(req, resp, next) {
        let data = {};
        try {
            let rules = {
                verification_token: `required|exists:otp_verifications,token`,
                otp_code: `required|digits:6`
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            let otp_verification = null;
            await OtpVerification.findOne({ 'token': req.body.verification_token, 'type': "user-login" }).exec().then(function(details) {
                return otp_verification = details;
            }).catch(function(e) {
                return resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });
            })

            if (!otp_verification) {
                return resp.status(200).send({ status: 'error', message: 'The OTP token is invalid', data: data });
            }

            if (await helpers.getDateDifference(new Date(), new Date(otp_verification.updated_at), 'minutes') > 20) {
                return resp.status(200).json({ 'status': "error", 'message': 'The OTP has expired, please resend the OTP to continue', data: data });
            }

            if (req.body.otp_code != otp_verification.otp) {
                return resp.status(200).json({ 'status': "error", 'message': 'The OTP entered is invalid', data: data });
            }

            await User.updateOne({ '_id': otp_verification.data.user_id }, { 'mobile_verified_at': Date.now() }).exec();

            req.body.email = otp_verification.data.email;
            req.body.password = otp_verification.data.password;
            await self.submit(req, resp, next, true);
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },

    resendOtp: async function(req, resp, next) {
        let data = {};
        try {
            let rules = {
                verification_token: `required|exists:otp_verifications,token`,
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            let otp_verification = null;
            await OtpVerification.findOne({ 'token': req.body.verification_token, 'type': "user-login" }).exec().then(function(details) {
                return otp_verification = details;
            }).catch(function(e) {
                return resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });
            })

            if (!otp_verification) {
                return resp.status(200).send({ status: 'error', message: 'The OTP token is invalid', data: data });
            }

            // const otp = await helpers.generateRandNumber(111111, 999999);
            const otp = 111111
            const content = `${otp} is your one-time password for verifying your account in CYTE. The otp is only valid for 20 min`

            if (helpers.sendSms(content, otp_verification.mobile)) {
                OtpVerification.updateOne({ token: req.body.verification_token }, { otp: otp, updated_at: Date.now() }, async function(e, details) {
                    if (e) return resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });

                    return resp.status(200).json({ 'status': "success", 'message': "The OTP has been resent successfully", data: data });
                })
            } else {
                return resp.status(200).send({ status: 'error', message: 'The otp cannot be sent. Please try again later', data: data });
            }
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    }
}