const mongoose = require('mongoose');
// const mongoosePaginate = require('mongoose-paginate-v2');
const mongooseAggregatePaginate = require('mongoose-aggregate-paginate-v2');

const Schema = mongoose.Schema;

const ProjectTaskUserSchema = new mongoose.Schema({
    task_id: {
        type: mongoose.Types.ObjectId,
        required: true
    },
    user_id: {
        type: mongoose.Types.ObjectId,
        required: true
    },
    status: {
        type: String,
        enum: ["pending", "inprogress", "completed"],
        required: true,
        default: "pending"
    },
    created_at: {
        type: Date,
        required: true,
        default: Date.now
    },
    updated_at: {
        type: Date,
        required: true,
        default: Date.now
    },
    deleted_at: {
        type: Date,
        required: false,
        default: null
    }
});

// ProjectTaskUserSchema.plugin(mongoosePaginate);
ProjectTaskUserSchema.plugin(mongooseAggregatePaginate);

const ProjectTaskUser = mongoose.model('project_task_users', ProjectTaskUserSchema);

module.exports = ProjectTaskUser;