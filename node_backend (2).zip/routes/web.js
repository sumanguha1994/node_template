const express = require('express');
const router = express.Router();

// Importing Middleware
const AuthMiddleware = require('../app/middleware/AuthMiddleware');

// Importing Controllers
const UsersController = require('../app/controllers/web/UsersController');
const ProjectsController = require('../app/controllers/web/ProjectsController.js');
const ProjectPostsController = require('../app/controllers/web/ProjectPostsController.js');

router.post('/getaccount', UsersController.getAccountDetails);
router.post('/profile/update', UsersController.updateProfile);
router.post('/user/email-verification/resend', UsersController.resendEmailVerification);
router.post('/user/email-verification/verify', UsersController.verifyEmail);

router.post('/project/list', ProjectsController.list);
router.post('/project/details', ProjectsController.details);
router.post('/project/members', ProjectsController.members);
router.post('/project/create', AuthMiddleware.checkRole(['manager']), ProjectsController.create);
router.post('/project/update', AuthMiddleware.checkRole(['manager']), ProjectsController.update);
router.post('/project/delete', AuthMiddleware.checkRole(['manager']), ProjectsController.delete);

router.post('/project/post/create', ProjectPostsController.create);
router.post('/project/post/fetch', ProjectPostsController.fetch);
router.post('/project/post/react', ProjectPostsController.react);
router.post('/project/post/comment', ProjectPostsController.comment);
router.post('/project/post/details', ProjectPostsController.details);

module.exports = router;