const helpers = require('../../common/helpers');
const { sendMail } = require('../../common/mailer');
const User = require('../../models/User');
const UserEmailVerification = require('../../models/UserEmailVerification');
const UserResource = require('../../resources/UserResource');

module.exports = {
    getAccountDetails: async function (req, resp) {
        let data = {};
        try {
            data.user = null;
            await User.findOne({ _id: req.auth.id }, '',).exec().then(function (user) {
                return data.user = new UserResource(user).exec();
            })

            return resp.status(200).send({ status: 'success', message: 'Success', data: data });
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },

    updateProfile: async function (req, resp) {
        let data = {};
        try {
            let rules = null;
            switch (req.body.operation) {
                case 'basicdetails':
                    rules = {
                        name: `required`,
                        // email: `required|email|unique:users,email,` + req.auth.id,
                        // mobile: `required|phoneNumber|unique:users,mobile,` + req.auth.id,
                    };
                    break;

                case 'password':
                    rules = {
                        current_password: `required|length:${global.CONFIG.rules.password.maxlength},${global.CONFIG.rules.password.minlength}`,
                        new_password: `required|length:${global.CONFIG.rules.password.maxlength},${global.CONFIG.rules.password.minlength}`,
                        new_password_confirmation: `required|length:${global.CONFIG.rules.password.maxlength},${global.CONFIG.rules.password.minlength}|same:new_password`,
                    };
                    break;

                case 'profilepicture':
                    rules = {};
                    break;

                default:
                    return resp.status(404).send({ status: 'error', message: 'Invalid Request Received', data: data });
            }

            if (rules) {
                const v = await helpers.validator(rules, req.body);
                if (!v.status) {
                    data.errors = v.errors;
                    return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
                }
            }

            let user_details = await User.findOne({ '_id': req.auth.id }).exec().then(function (row) {
                return row;
            }).catch(function (e) {
                resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });
                process.exit(1);
            })

            let action = false;
            let successmsg = null;
            switch (req.body.operation) {
                case 'basicdetails':
                    var document = {
                        name: req.body.name,
                        // email: req.body.email,
                        // mobile: req.body.mobile,
                        updated_at: Date.now(),
                    };

                    await User.updateOne({ '_id': req.auth.id }, document, function (err, details) {
                        if (err) {
                            resp.status(200).send({ status: 'error', message: err ? err.message : 'DB Error Occured', data: data });
                            process.exit(1);
                        }

                        action = true;
                        successmsg = "Profile updated successfully";
                    })
                    break;

                case 'password':
                    if (!await helpers.bcryptCheck(req.body.current_password, req.auth.data.password)) {
                        return resp.status(200).json({ status: 'error', message: 'The current password you entered is invalid', data: data });
                    }

                    var document = {
                        password: await helpers.bcryptMake(req.body.new_password),
                    };

                    await User.updateOne({ '_id': req.auth.id }, document, function (err, details) {
                        if (err) {
                            resp.status(200).send({ status: 'error', message: err ? err.message : 'DB Error Occured', data: data });
                            process.exit(1);
                        }

                        action = true;
                        successmsg = "Password changed successfully";
                    })
                    break;

                case 'profilepicture':
                    var document = {};

                    if (req.files && req.files.image !== undefined) {
                        const uploadImage = await helpers.uploadFile(req.files.image, 'users/profile', ['JPG', 'JPEG', 'PNG', 'jpg', 'jpeg', 'png']);
                        if (uploadImage.status == false) {
                            return resp.status(200).json({ 'status': "error", 'message': "File upload error : " + uploadImage.message, data: data });
                        }

                        if (user_details.image) {
                            await helpers.deleteFile(user_details.image, 'users/profile');
                        }

                        document.image = uploadImage.filename;
                    } else {
                        return resp.status(200).json({ 'status': "error", 'message': "Please select a image to upload.", data: data });
                    }


                    await User.updateOne({ '_id': req.auth.id }, document, function (err, details) {
                        if (err) {
                            resp.status(200).send({ status: 'error', message: err ? err.message : 'DB Error Occured', data: data });
                            process.exit(1);
                        }

                        action = true;
                        successmsg = "Profile Picture Updated Successfully";
                    })
                    break;

                default:
                    return resp.status(404).send({ status: 'error', message: 'Invalid Request Received', data: data });
            }

            if (action) {
                data.user = null;
                await User.findOne({ _id: req.auth.id }, '',).exec().then(function (user) {
                    return data.user = new UserResource(user).exec();
                })

                return resp.status(200).send({ status: 'success', message: successmsg ? successmsg : 'Profile Updated Successfully', data: data });
            } else {
                return resp.status(400).send({ status: 'error', message: 'Invalid Request Received', data: data });
            }
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },

    /**
     * ===========================
     * USER VERIFICATION FUNCTIONS
     * ===========================
     */

    resendEmailVerification: async function (req, resp) {
        let data = {};
        try {
            if (req.auth?.email_verified_at) {
                return resp.status(200).send({ status: 'error', message: 'Your account\'s email is already verified', data: data });
            }

            let document = {
                'token': await helpers.generateRandomString(60),
                'user_id': req.auth.id,
                'email': req.auth.data.email,
            }

            await UserEmailVerification.deleteMany({ 'user_id': document.user_id }).exec();

            await UserEmailVerification.create(document, async function (e, details) {
                if (e) return resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });

                const send_email = await sendMail({
                    to: document.email,
                    subject: "CYTE - ACCOUNT VERIFICATION",
                    type: "member-account-verification",
                    data: {
                        user_name: req.auth.data.name,
                        user_email: req.auth.data.email,
                        verification_token: details.token,
                    }
                })

                return resp.status(200).json({
                    'status': "success",
                    'message': "Verification email sent successfully to " + document.email,
                    data: data
                });
            })
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },

    verifyEmail: async function (req, resp) {
        let data = {};
        try {
            rules = {
                email: `required|email`,
                token: `required`,
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            const verification = await UserEmailVerification.findOne({ 'token': req.body.token, }).exec().then(function (row) {
                return row;
            }).catch(function (e) {
                resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });
                process.exit(1);
            })

            if (!verification) {
                return resp.status(200).send({ status: 'error', message: 'The link is invalid', data: data });
            }

            const user_details = await User.findOne({ '_id': verification.user_id, }).exec().then(function (row) {
                return row;
            }).catch(function (e) {
                resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });
                process.exit(1);
            })

            if (!user_details) {
                return resp.status(200).send({ status: 'error', message: 'The user didn\'t matched', data: data });
            }

            if (user_details._id != req.auth.id) {
                return resp.status(200).send({ status: 'error', message: 'The link your are trying to access is unauthorized', data: data });
            }

            if (user_details.email_verified_at) {
                return resp.status(200).send({ status: 'success', message: 'Your account\'s email is already verified', data: data });
            }

            if (user_details.email == verification.email) {
                await User.updateOne({ '_id': user_details._id }, { 'email_verified_at': Date.now() }).exec().then(function (details) {
                    return resp.status(200).send({ status: 'success', message: 'The email verified successfully', data: data });
                }).catch(function (e) {
                    return resp.status(200).send({ status: 'error', message: 'The email verification cannot be completed', data: data });
                })
            } else {
                return resp.status(200).send({ status: 'error', message: 'Oops!! the email verification failed.', data: data });
            }
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    }
}