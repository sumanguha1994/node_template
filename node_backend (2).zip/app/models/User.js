const mongoose = require('mongoose');
// const mongoosePaginate = require('mongoose-paginate-v2');
const mongooseAggregatePaginate = require('mongoose-aggregate-paginate-v2');

const Schema = mongoose.Schema;

const UserSchema = new mongoose.Schema({
    role: {
        type: String,
        enum: ['superadmin', 'manager', 'employee', 'contractor', 'supplier', 'safety_manager'],
        required: true
    },
    name: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true,
        unique: true,
    },
    mobile: {
        type: String,
        required: false,
        default: null,
        unique: true,
    },
    password: {
        type: String,
        required: true
    },
    department_id: {
        type: mongoose.Types.ObjectId,
        required: false,
        default: null
    },
    division_id: {
        type: mongoose.Types.ObjectId,
        required: false,
        default: null
    },
    image: {
        type: String,
        required: false,
        default: null
    },
    status: {
        type: String,
        enum: ["active", "inactive"],
        required: true,
        default: "active"
    },
    email_verified_at: {
        type: Date,
        required: false,
        default: null
    },
    mobile_verified_at: {
        type: Date,
        required: false,
        default: null
    },
    created_at: {
        type: Date,
        required: true,
        default: Date.now
    },
    updated_at: {
        type: Date,
        required: true,
        default: Date.now
    },
    deleted_at: {
        type: Date,
        required: false,
        default: null
    },
});

// UserSchema.plugin(mongoosePaginate);
UserSchema.plugin(mongooseAggregatePaginate);

const User = mongoose.model('users', UserSchema);

module.exports = User;