const mongoose = require('mongoose');
// const mongoosePaginate = require('mongoose-paginate-v2');
const mongooseAggregatePaginate = require('mongoose-aggregate-paginate-v2');

const Schema = mongoose.Schema;

const ProjectSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    slug: {
        type: String,
        required: true,
        unique: true
    },
    location: {
        type: String,
        required: true
    },
    image: {
        type: String,
        required: false,
        default: null
    },
    status: {
        type: String,
        enum: ["active", "inactive"],
        required: true,
        default: "active"
    },
    created_by: {
        type: mongoose.Types.ObjectId,
        required: true,
    },
    created_at: {
        type: Date,
        required: true,
        default: Date.now
    },
    updated_at: {
        type: Date,
        required: true,
        default: Date.now
    },
    deleted_at: {
        type: Date,
        required: false,
        default: null
    },
});

// ProjectSchema.plugin(mongoosePaginate);
ProjectSchema.plugin(mongooseAggregatePaginate);

const Project = mongoose.model('projects', ProjectSchema);

module.exports = Project;