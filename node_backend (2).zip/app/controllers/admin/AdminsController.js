const helpers = require('../../common/helpers');
const User = require('../../models/User');
const UserResource = require('../../resources/UserResource');

module.exports = {
    updateProfile: async function(req, resp) {
        let data = {};
        try {
            let rules = null;
            switch (req.body.operation) {
                case 'basicdetails':
                    rules = {
                        name: `required`,
                        // email: `required|email|unique:users,email,` + req.auth.id,
                        mobile: `required|phoneNumber|unique:users,mobile,` + req.auth.id,
                    };
                    break;

                case 'password':
                    rules = {
                        current_password: `required|length:${global.CONFIG.rules.password.maxlength},${global.CONFIG.rules.password.minlength}`,
                        new_password: `required|length:${global.CONFIG.rules.password.maxlength},${global.CONFIG.rules.password.minlength}`,
                        new_password_confirmation: `required|length:${global.CONFIG.rules.password.maxlength},${global.CONFIG.rules.password.minlength}|same:new_password`,
                    };
                    break;

                default:
                    return resp.status(404).send({ status: 'error', message: 'Invalid Request Received', data: data });
            }

            if (rules) {
                const v = await helpers.validator(rules, req.body);
                if (!v.status) {
                    data.errors = v.errors;
                    return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
                }
            }

            let action = false;
            let successmsg = null;
            switch (req.body.operation) {
                case 'basicdetails':
                    var document = {
                        name: req.body.name,
                        // email: req.body.email,                        
                        mobile: req.body.mobile,
                        updated_at: Date.now(),
                    };

                    await User.updateOne({ '_id': req.auth.id }, document, function(err, details) {
                        if (err) {
                            resp.status(200).send({ status: 'error', message: err ? err.message : 'DB Error Occured', data: data });
                            process.exit(1);
                        }

                        action = true;
                        successmsg = "Profile updated successfully";
                    })
                    break;

                case 'password':
                    if (!await helpers.bcryptCheck(req.body.current_password, req.auth.data.password)) {
                        return resp.status(200).json({ status: 'error', message: 'The current password you entered is invalid', data: data });
                    }

                    var document = {
                        password: await helpers.bcryptMake(req.body.new_password),
                    };

                    await User.updateOne({ '_id': req.auth.id }, document, function(err, details) {
                        if (err) {
                            resp.status(200).send({ status: 'error', message: err ? err.message : 'DB Error Occured', data: data });
                            process.exit(1);
                        }

                        action = true;
                        successmsg = "Password changed successfully";
                    })
                    break;

                default:
                    return resp.status(404).send({ status: 'error', message: 'Invalid Request Received', data: data });
            }

            if (action) {
                data.user = null;
                await User.findOne({ _id: req.auth.id }, '', ).exec().then(function(user) {
                    return data.user = new UserResource(user).exec();
                })

                return resp.status(200).send({ status: 'success', message: successmsg ? successmsg : 'Profile Updated Successfully', data: data });
            } else {
                return resp.status(400).send({ status: 'error', message: 'Invalid Request Received', data: data });
            }
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    }
}