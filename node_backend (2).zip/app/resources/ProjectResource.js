const Resource = require('resources.js');

class ProjectResource extends Resource {
    toArray() {
        let doc = {
            _id: this._id || null,
            name: this.name || null,
            slug: this.slug || null,
            location: this.location || null,
            image: this.image || null,
            status: this.status || null,
            created_by: this.created_by || null,
            created_at: this.created_at || null,
            updated_at: this.updated_at || null,
        }

        if (this.image !== undefined) {
            doc.image_path = global.CONFIG.app.url + '/public/uploads/projects/' + this.image;
        } else {
            doc.image_path = global.CONFIG.app.url + '/public/images/placeholder.png';
        }

        return doc;
    }
}

module.exports = ProjectResource;