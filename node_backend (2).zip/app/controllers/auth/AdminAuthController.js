const helpers = require('../../common/helpers');
const User = require('../../models/User');
const UserResource = require('../../resources/UserResource');

module.exports = {
    login: async function(req, resp) {
        let data = {};
        try {
            let rules = {
                email: `required|email`,
                password: `required|length:${global.CONFIG.rules.password.maxlength},${global.CONFIG.rules.password.minlength}`,
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            let user = null;
            await User.findOne({ 'email': req.body.email, 'role': "superadmin", 'deleted_at': null }, '').exec().then(function(details) {
                return user = details;
            }).catch(function(e) {
                resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });
                process.exit(1);
            })

            if (!user) {
                return resp.status(200).json({ status: 'error', message: 'The email you entered is invalid', data: data });
            }

            if (user.status != "active") {
                return resp.status(200).json({ status: 'error', message: 'The account has been blocked', data: data });
            }

            if (!await helpers.bcryptCheck(req.body.password, user.password)) {
                return resp.status(200).json({ status: 'error', message: 'The password you entered is invalid', data: data });
            }

            data.user = new UserResource(user).exec();
            data.token = await helpers.generateJwtToken({ 'user_id': user._id, 'email': user.email, 'role': user.role });
            return resp.status(200).send({ status: 'success', message: "Logedin Successfully", data: data });
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },

    getAccountDetails: async function(req, resp) {
        let data = {};
        try {
            data.user = null;
            await User.findOne({ _id: req.auth.id }, '', ).exec().then(function(user) {
                return data.user = new UserResource(user).exec();
            })

            return resp.status(200).send({ status: 'success', message: 'Success', data: data });
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    }
}