const mongoose = require('mongoose');
const helpers = require('../../common/helpers');

const ProjectTask = require('../../models/ProjectTask');
const ProjectTaskResource = require('../../resources/ProjectTaskResource');

module.exports = {
    view: async function(req, resp) {
        let data = {};
        try {
            rules = {
                project_id: `required|mongoId|exists:projects,_id`,
                pageno: `required|numeric`,
                searchkey: `nullable`,
                length: `nullable`,
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            const options = {
                page: req.body.pageno,
                limit: req.body.length ? req.body.length : global.CONFIG.app.pagination.perpage,
                sort: { created_at: -1 },
            };

            var filter_option = {
                $match: {
                    $and: [{
                        'project_id': mongoose.Types.ObjectId(req.body.project_id),
                        'deleted_at': null
                    }]
                }
            };

            if (req.body.searchkey) {
                filter_option.$match.$or = [
                    { "end_date": { $regex: ".*" + req.body.searchkey + ".*" } },
                    { "priority": { $regex: ".*" + req.body.searchkey + ".*" } },
                    { "description": { $regex: ".*" + req.body.searchkey + ".*" } },
                ];
            }

            var projectTaskAggregrate = ProjectTask.aggregate([
                filter_option,
                {
                    $lookup: {
                        from: 'projects',
                        localField: 'project_id',
                        foreignField: '_id',
                        as: 'project'
                    }
                },
                {
                    $lookup: {
                        from: 'divisions',
                        localField: 'division_id',
                        foreignField: '_id',
                        as: 'division'
                    }
                },
                {
                    $addFields: {
                        project: {
                            $arrayElemAt: ["$project", 0]
                        },
                        division: {
                            $arrayElemAt: ["$division", 0]
                        },
                    }
                },
            ]);

            ProjectTask.aggregatePaginate(projectTaskAggregrate, options, function(e, rows) {
                if (e) return resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });

                rows.docs = ProjectTaskResource.collection(rows.docs);

                data.project_tasks = rows
                return resp.status(200).json({ status: 'success', 'message': 'Project tasks fetched successfully', data: data });
            })
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },

    add: async function(req, resp) {
        let data = {};
        try {
            let rules = {
                project_id: `required|mongoId|exists:projects,_id`,
                division_id: `required|mongoId|exists:divisions,_id`,
                end_date: `required|date`,
                priority: `required|in:low,moderate,high`,
                description: `required`,
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            let document = {
                'project_id': req.body.project_id,
                'division_id': req.body.division_id,
                'end_date': req.body.end_date,
                'priority': req.body.priority,
                'description': req.body.description,
            }

            ProjectTask.create(document, async function(e, details) {
                if (e) return resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });

                data.project_task = new ProjectTaskResource(details).exec();

                return resp.status(200).json({ 'status': "success", 'message': "Project task created successfully", data: data });
            })
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },

    edit: async function(req, resp) {
        let data = {};
        try {
            let rules = {
                task_id: `required|mongoId|exists:project_tasks,_id`,
                // project_id: `required|mongoId|exists:projects,_id`,
                end_date: `required|date`,
                priority: `required|in:low,moderate,high`,
                description: `required`,
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            let document = {
                // 'project_id': req.body.project_id,
                'end_date': req.body.end_date,
                'priority': req.body.priority,
                'description': req.body.description,
                'updated_at': Date.now(),
            }

            await ProjectTask.updateOne({ '_id': req.body.task_id }, document, async function(err, details) {
                if (err) {
                    return resp.status(200).send({ status: 'error', message: err ? err.message : 'DB Error Occured', data: data });
                }

                data.project_task = null;
                await ProjectTask.findOne({ _id: req.body.task_id }, '', ).exec().then(function(project_task) {
                    return data.project_task = new ProjectTaskResource(project_task).exec();
                })

                return resp.status(200).send({ status: 'success', message: 'Project task updated successfully', data: data });
            })
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },

    changeStatus: async function(req, resp) {
        let data = {};
        try {
            rules = {
                task_id: `required|mongoId|exists:project_tasks,_id`,
                status: `required|in:active,inactive`,
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            var document = {
                status: req.body.status,
                updated_at: Date.now(),
            };

            await ProjectTask.updateOne({ '_id': req.body.task_id }, document, async function(err, details) {
                if (err) {
                    return resp.status(200).send({ status: 'error', message: err ? err.message : 'DB Error Occured', data: data });
                }

                data.project_task = null;
                await ProjectTask.findOne({ _id: req.body.task_id }, '', ).exec().then(function(details) {
                    return data.project_task = new ProjectTaskResource(details).exec();
                });

                return resp.status(200).send({
                    status: 'success',
                    message: (data.project_task.status == 'active') ? "Project task activated successfully" : "Project task deactivated successfully",
                    data: data
                });
            })
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },

    delete: async function(req, resp) {
        let data = {};
        try {
            rules = {
                task_id: `required|mongoId|exists:project_tasks,_id`,
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            var document = {
                deleted_at: Date.now(),
            };

            await ProjectTask.updateOne({ '_id': req.body.task_id }, document, async function(err, details) {
                if (err) {
                    return resp.status(200).send({ status: 'error', message: err ? err.message : 'DB Error Occured', data: data });
                }

                return resp.status(200).send({ status: 'success', message: "Project task deleted successfully", data: data });
            })
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },

    details: async function(req, resp) {
        let data = {};
        try {
            rules = {
                task_id: `required|mongoId|exists:project_tasks,_id`,
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            var filter_option = {
                $match: {
                    $and: [{
                        '_id': mongoose.Types.ObjectId(req.body.task_id),
                        'deleted_at': null
                    }]
                }
            };

            data.project_task = null;
            await ProjectTask.aggregate([
                filter_option,
                {
                    $lookup: {
                        from: 'projects',
                        localField: 'project_id',
                        foreignField: '_id',
                        as: 'project'
                    }
                },
                {
                    $lookup: {
                        from: 'divisions',
                        localField: 'division_id',
                        foreignField: '_id',
                        as: 'division'
                    }
                },
                {
                    $addFields: {
                        project: {
                            $arrayElemAt: ["$project", 0]
                        },
                        division: {
                            $arrayElemAt: ["$division", 0]
                        },
                    }
                },
            ]).exec().then(function(result) {
                let details = result[0] ? result[0] : null;
                if (details) {
                    return data.project_task = new ProjectTaskResource(details).exec();
                }
            });

            if (!data.project_task) {
                return resp.status(200).send({ status: 'error', message: 'Project task not found', data: data });
            }

            return resp.status(200).send({ status: 'success', message: "Success", data: data });
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    }
}