const Resource = require('resources.js');
const UserResource = require('./UserResource');

class ProjectChannelPostCommentResource extends Resource {
    toArray() {
        let doc = {
            post_id: this.post_id || null,
            user_id: this.user_id || null,
            parent_id: this.parent_id || null,
            comment: this.comment || null,
            status: this.status || null,
            created_at: this.created_at || null,
            updated_at: this.updated_at || null,
        }

        if (this.user !== undefined) {
            doc.user = new UserResource(this.user).exec();
        }

        return doc;
    }
}

module.exports = ProjectChannelPostCommentResource;