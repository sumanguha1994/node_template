const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const ProjectChannelPostCommentSchema = new mongoose.Schema({
    post_id: {
        type: mongoose.Types.ObjectId,
        required: true
    },
    user_id: {
        type: mongoose.Types.ObjectId,
        required: true
    },
    parent_id: {
        type: mongoose.Types.ObjectId,
        required: false,
        default: null
    },
    comment: {
        type: String,
        required: true,
    },
    status: {
        type: String,
        enum: ["active", "inactive"],
        required: true,
        default: "active"
    },
    created_at: {
        type: Date,
        required: true,
        default: Date.now
    },
    updated_at: {
        type: Date,
        required: true,
        default: Date.now
    },
    deleted_at: {
        type: Date,
        required: false,
        default: null
    },
});

const ProjectChannelPostComment = mongoose.model('project_channel_post_comments', ProjectChannelPostCommentSchema);

module.exports = ProjectChannelPostComment;