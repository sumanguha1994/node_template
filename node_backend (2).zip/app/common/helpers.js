// const { Validator } = require('node-input-validator');
const niv = require('node-input-validator');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const fs = require('fs');

module.exports = {
    bcryptMake: async function (string) {
        if (string) {
            return bcrypt.hashSync(string, parseInt(global.CONFIG.bcrypt.saltrounds));
        } else {
            return false;
        }
    },

    bcryptCheck: async function (string, hash) {
        if (string && hash) {
            return bcrypt.compareSync(string, hash);
        } else {
            return false;
        }
    },

    validator: async function (rules, request) {
        for (const key in rules) {
            if (Object.hasOwnProperty.call(rules, key)) {
                const rule = rules[key];

                if (rule.includes('sometimes')) { // If sometimes rule is present
                    if (!request[key]) { // If the value not present, then skip the rule
                        delete rules[key]; 
                    }
                }
            }
        }

        const v = new niv.Validator(request, rules);
        const matched = await v.check();
        if (!matched) {
            return { 'status': false, 'errors': v.errors };
        } else {
            return { 'status': true };
        }
    },

    generateJwtToken: async function (document) {
        // const options = { expiresIn: '365d' };
        const options = {};
        const token = jwt.sign(document, process.env.JWT_TOKEN, options);
        return token;
    },

    generateRandomString: async function (length = 10) {
        var result = '';
        var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        var charactersLength = characters.length;
        for (var i = 0; i < length; i++) {
            result += characters.charAt(Math.floor(Math.random() *
                charactersLength));
        }

        return result;
    },

    getDateDifference: async function (date1, date2, retType) {
        const diffInMs = Math.abs(date2 - date1);
        switch (retType) {
            case 'days':
                return diffInMs / (1000 * 60 * 60 * 24);

            case 'hours':
                return diffInMs / (1000 * 60 * 60);

            case 'minutes':
                return diffInMs / (1000 * 60);

            case 'seconds':
                return diffInMs / 1000;

            default:
                return false
        }
    },

    generateRandNumber: async function (min, max) {
        return Math.floor(Math.random() * (max - min + 1) + min);
    },

    sendSms: async function (content, mobile) {
        console.log("---- OTP SEND : " + mobile + " -> " + content)
        return true
    },

    uploadFile: async function (file, path, allExt = []) {
        return new Promise(function (resolve, reject) {
            if (file) {
                if (allExt.length > 0) { // Check if extension checking is present
                    var ext = file.name.split('.'); ext = ext[ext.length - 1]; // Retreiving file extension
                    if (!allExt.includes(ext)) {
                        resolve({ status: false, message: "The file uploaded is not supprted" });
                    }
                }


                const fileName = Date.now() + '_' + file.name;
                file.mv(`${global.CONFIG.DIR_PATH}/public/uploads/${path}/${fileName}`, err => {
                    if (err) {
                        resolve({ status: false, message: err ? err.message : "File upload failed" })
                    }

                    resolve({ status: true, filename: fileName })
                });
            } else {
                resolve({ status: false, message: "File not exist" })
            }
        });
    },

    deleteFile: async function (fileName, path) {
        return new Promise(function (resolve, reject) {
            fs.unlink(`${global.CONFIG.DIR_PATH}/public/uploads/${path}/${fileName}`, err => {
                if (err) {
                    resolve({ status: false, message: err ? err.message : "File upload failed" })
                }

                resolve({ status: true, message: "File removed successfully" });
            })
        });
    },

    generateCollectionSlug: async function (Model, text, attribute, _idToSkip = null) {
        return new Promise(async (resolve, reject) => {
            let iteration = 0;
            do {
                var slug = text.toLowerCase().replace(/ /g, '-').replace(/[^\w-]+/g, '');
                if (iteration != 0) {
                    slug = slug + "-" + iteration;
                }

                var filter = {
                    [attribute]: slug
                }

                if (_idToSkip) filter._id = { $ne: _idToSkip }

                docExists = await Model.findOne(filter).select(attribute);

                iteration += 1;
            } while (docExists);

            resolve(slug);
        })
    }
}

// Node-Input-Validator Unique Rule Function
niv.extend('unique', async ({ value, args }) => {
    const field = args[1];

    let condition = {};

    condition[field] = value;

    // add ignore condition
    if (args[2]) {
        condition['_id'] = { $ne: mongoose.Types.ObjectId(args[2]) };
    }

    let rowExists = await mongoose.model(args[0]).findOne(condition).select(field);
    if (rowExists) {
        return false;
    }

    return true;
});

// Node-Input-Validator Exists Rule Function
niv.extend('exists', async ({ value, args }) => {
    const field = args[1];

    let condition = {};

    condition[field] = value;

    let rowExists = await mongoose.model(args[0]).findOne(condition).select(field);
    if (rowExists) {
        return true;
    }

    return false;
});