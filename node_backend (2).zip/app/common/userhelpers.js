const Project = require('../models/Project');
const ProjectChannelUser = require('../models/ProjectChannelUser');
const mongoose = require('mongoose');

module.exports = {
    getAccessibleProjects: async function (user_id, condition = {}) {
        return new Promise(async (resolve, reject) => {
            if (condition.status === undefined) {
                condition.status = 'active';
            }

            if (condition.deleted_at === undefined) {
                condition.deleted_at = null;
            }

            await Project.find(condition).select('_id').exec().then(function (results) {
                resolve(results.map(a => a._id));
            }).catch((err) => {
                resolve([]);
            })
        })
    },

    // getAccessibleProjects: async function (user_id, condition = {}) {
    //     return new Promise(async (resolve, reject) => {
    //         // if (condition.status === undefined) {
    //         //     condition.status = 'active';
    //         // }

    //         if (condition.deleted_at === undefined) {
    //             condition.deleted_at = null;
    //         }

    //         // condition.user_id = user_id

    //         await ProjectChannelUser.find(condition).select('project_id').exec().then(function (results) {
    //             // console.log('results : ', results);
    //             resolve(results.map(a => a.project_id));
    //         }).catch((err) => {
    //             resolve([]);
    //         })
    //     })
    // },

    getAccessibleProjectDivisions: async function (user_id, project_id, condition = {}) {
        return new Promise(async (resolve, reject) => {
            condition.user_id = mongoose.Types.ObjectId(user_id)
            condition.project_id = mongoose.Types.ObjectId(project_id)

            if (condition.deleted_at === undefined) {
                condition.deleted_at = null;
            }

            await ProjectChannelUser.find(condition).select('division_id').exec().then(function (results) {
                resolve([...new Set(results.map(item => item.division_id))])
            }).catch((err) => {
                resolve([]);
            })
        })
    },

    checkProjectDivisionAccesibility: async function (user_id, project_id, division_id, condition = {}) {
        return new Promise(async (resolve, reject) => {
            condition.user_id = mongoose.Types.ObjectId(user_id)
            condition.project_id = mongoose.Types.ObjectId(project_id)
            condition.division_id = mongoose.Types.ObjectId(division_id)

            if (condition.deleted_at === undefined) {
                condition.deleted_at = null;
            }

            // console.log('checkProjectDivisionAccesibility() - condition: ', condition);

            await ProjectChannelUser.findOne(condition).exec().then(function (result) {
                if (result) {
                    resolve(true);
                } else {
                    resolve(false);
                }
            }).catch((err) => {
                resolve(false);
            })
        });
    },

    fetchProjectChannelAssignedMembers: async function (project_id, division_id, condition = {}) {
        return new Promise(async (resolve, reject) => {
            if (!division_id) {
                return resolve([]);
            }

            condition.project_id = project_id;
            condition.division_id = division_id;

            if (condition.deleted_at === undefined) {
                condition.deleted_at = null;
            }

            let usersIdsAssigned = []
            await ProjectChannelUser.find(condition).select('user_id').exec().then(function (results) {
                results.forEach(element => {
                    usersIdsAssigned.push(element.user_id);
                });
            })

            return resolve(usersIdsAssigned);
        })
    }
}