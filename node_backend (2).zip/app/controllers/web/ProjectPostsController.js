const userhelpers = require('../../common/userhelpers');
const helpers = require('../../common/helpers');
const mongoose = require('mongoose');

const Project = require('../../models/Project');
const ProjectChannelPost = require('../../models/ProjectChannelPost');
const ProjectChannelPostResource = require('../../resources/ProjectChannelPostResource');
const ProjectChannelPostCommentResource = require('../../resources/ProjectChannelPostCommentResource');
const ProjectChannelPostReact = require('../../models/ProjectChannelPostReact');
const ProjectChannelPostComment = require('../../models/ProjectChannelPostComment');

module.exports = {
    create: async function (req, resp) {
        let data = {};
        try {
            let rules = {
                project_id: `required|mongoId|exists:projects,_id`,
                division_id: `sometimes|mongoId|exists:divisions,_id`,
                description: `required`,
                creating_thread: `sometimes|in:true,false`,
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            if (req.body.division_id) {
                const accessibility = await userhelpers.checkProjectDivisionAccesibility(req.auth.id, req.body.project_id, req.body.division_id);
                if (!accessibility) {
                    return resp.status(200).send({ status: 'error', message: 'You don\'t have access to this project channel.', data: data });
                }
            }

            let uploadsDocument = [];
            if (req.files && req.files.uploads !== undefined) {
                if (Array.isArray(req.files.uploads)) {
                    for (const key in req.files.uploads) {
                        if (Object.hasOwnProperty.call(req.files.uploads, key)) {
                            const upload = req.files.uploads[key];

                            let uploadFile = await helpers.uploadFile(upload, 'projects/posts');
                            if (uploadFile.status == true) {
                                uploadsDocument.push({
                                    file: uploadFile.filename
                                })
                            }
                        }
                    }
                } else {
                    let uploadFile = await helpers.uploadFile(req.files.uploads, 'projects/posts');
                    if (uploadFile.status == true) {
                        uploadsDocument.push({
                            file: uploadFile.filename
                        })
                    }
                }
            }

            let document = {
                'user_id': req.auth.id,
                'project_id': req.body.project_id,
                'description': req.body.description,
                'uploads': uploadsDocument
            }

            if (req.body.division_id) { // If division id is blank, then it will go the the General Channel (i.e., PUBLIC)
                document.division_id = req.body.division_id
            }

            document.type = "post";
            if (req.body.creating_thread == 'true') {
                document.type = "thread";
            }

            await ProjectChannelPost.create(document, async function (e, details) {
                if (e) return resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });

                let successMsg = "Post successfully posted to the channel";
                if (details.type == 'thread') {
                    successMsg = "Thread successfully created to the channel";
                }

                data.post = new ProjectChannelPostResource(details).exec();
                return resp.status(200).send({ status: 'success', message: successMsg, data: data });
            })
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },

    fetch: async function (req, resp) {
        let data = {};
        try {
            rules = {
                pageno: `required|numeric`,
                length: `nullable`,
                project_id: `required|mongoId|exists:projects,_id`,
                type: `sometimes|in:post,thread`,
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            const options = {
                page: req.body.pageno,
                limit: req.body.length ? req.body.length : global.CONFIG.app.pagination.perpage,
                sort: { created_at: -1 },
            };

            var filter_option = {
                $match: {
                    $and: [
                        { project_id: mongoose.Types.ObjectId(req.body.project_id) },
                        { division_id: req.body.division_id ? mongoose.Types.ObjectId(req.body.division_id) : null },
                        { deleted_at: null },
                        { status: 'active' },
                    ]
                }
            };

            if (req.body.type) {
                filter_option.$match.$and.push({
                    type: req.body.type
                });
            }

            var queryAggregrate = ProjectChannelPost.aggregate([
                filter_option,
                { $lookup: { from: 'users', localField: 'user_id', foreignField: '_id', as: 'user' }, },
                { $lookup: { from: 'project_channel_post_reacts', localField: '_id', foreignField: 'post_id', as: 'reacts' }, },
                {
                    /** GET RECENT REACTIONS */
                    $lookup: {
                        from: 'project_channel_post_reacts',
                        as: 'recent_reacts',
                        let: { post_id: '$_id' },
                        pipeline: [
                            { $match: { $expr: { $eq: ['$post_id', '$$post_id'] } }, },
                            { $lookup: { from: 'users', localField: 'user_id', foreignField: '_id', as: 'user' }, },
                            { $sort: { created_at: 1 } },
                            { $limit: 10 },
                            {
                                $addFields: {
                                    user: { $arrayElemAt: ["$user", 0] },
                                },
                            },
                        ]
                    }
                },
                {
                    /** GET CURRENT USER REACT */
                    $lookup: {
                        from: 'project_channel_post_reacts',
                        as: 'user_react',
                        let: { post_id: '$_id' },
                        pipeline: [
                            { $match: { $expr: { $eq: ['$post_id', '$$post_id'] }, $and: [{ 'user_id': mongoose.Types.ObjectId(req.auth.id) }] }, },
                        ]
                    }
                },
                {
                    $lookup: {
                        from: 'project_channel_post_comments',
                        as: 'comments',
                        let: { post_id: '$_id' },
                        pipeline: [
                            { $match: { $expr: { $eq: ['$post_id', '$$post_id'] }, $and: [{ parent_id: null }] }, },
                            // { $lookup: { from: 'users', localField: 'user_id', foreignField: '_id', as: 'user' }, },
                            // { $sort: { created_at: 1 } },
                            // { $limit: 10 },
                            // {
                            //     $addFields: {
                            //         user: { $arrayElemAt: ["$user", 0] },
                            //     },
                            // },
                        ]
                    },
                },
                {
                    /** GET RECENT COMMENTS */
                    $lookup: {
                        from: 'project_channel_post_comments',
                        as: 'recent_comments',
                        let: { post_id: '$_id' },
                        pipeline: [
                            { $match: { $expr: { $eq: ['$post_id', '$$post_id'] }, $and: [{ parent_id: null }] }, },
                            { $lookup: { from: 'users', localField: 'user_id', foreignField: '_id', as: 'user' }, },
                            { $sort: { created_at: 1 } },
                            { $limit: 10 },
                            {
                                $addFields: {
                                    user: { $arrayElemAt: ["$user", 0] },
                                },
                            },
                        ]
                    }
                },
                {
                    $addFields: {
                        user: { $arrayElemAt: ["$user", 0] },
                        user_react: { $arrayElemAt: ["$user_react", 0] }
                    },
                },
            ]);

            ProjectChannelPost.aggregatePaginate(queryAggregrate, options, function (e, rows) {
                if (e) return resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });

                /**
                 * =================================
                 * SEND CUSTOM SETTINGS TO RESOURCES
                 * =================================
                 * =================================
                 */
                rows.docs = rows.docs.map(obj => ({
                    ...obj,
                    RESP_SETTINGS: {
                        reacts_count: true,
                        recent_reacts: true,
                        comments_count: true,
                        recent_comments: true,
                        user_react: true,
                    }
                }))

                rows.docs = ProjectChannelPostResource.collection(rows.docs);

                data.posts = rows
                return resp.status(200).json({ status: 'success', 'message': 'Posts fetched successfully', data: data });
            })
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },

    react: async function (req, resp) {
        let data = {};
        try {
            let rules = {
                post_id: `required|mongoId|exists:project_channel_posts,_id`,
                type: `required|in:like,fire,rock,support`
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            if (await ProjectChannelPostReact.exists({ post_id: req.body.post_id, user_id: req.auth.id }) == false) {
                /**
                 * --------------------------------------------------
                 * If no previous doc is present, then push a new one
                 * --------------------------------------------------
                 * --------------------------------------------------
                 */

                ProjectChannelPostReact.create({
                    user_id: req.auth.id,
                    post_id: req.body.post_id,
                    type: req.body.type
                }).then(function (result) {
                    return resp.status(200).json({ 'status': "success", 'message': 'Reacted to the post successfully', data: data });
                }).catch(function (e) {
                    return resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });
                })
            } else if (await ProjectChannelPostReact.exists({ post_id: req.body.post_id, user_id: req.auth.id, type: { $ne: req.body.type } }) == true) {
                /**
                 * --------------------------------------------------------------------------
                 * If other type doc is present, then updating the old one, with the new type
                 * --------------------------------------------------------------------------
                 * --------------------------------------------------------------------------
                 */

                ProjectChannelPostReact.updateOne({
                    user_id: req.auth.id,
                    post_id: req.body.post_id,
                }, {
                    type: req.body.type
                }).then(function (result) {
                    return resp.status(200).json({ 'status': "success", 'message': 'Reacted to the post successfully', data: data });
                }).catch(function (e) {
                    return resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });
                })
            } else {
                /**
                 * ------------------------------------------
                 * Same type doc is present, then removing it
                 * ------------------------------------------
                 * ------------------------------------------
                 */

                ProjectChannelPostReact.deleteMany({
                    user_id: req.auth.id,
                    post_id: req.body.post_id,
                }).then(function (result) {
                    return resp.status(200).json({ 'status': "success", 'message': 'Reaction removed from the post successfully', data: data });
                }).catch(function (e) {
                    return resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });
                })
            }
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },

    comment: async function (req, resp) {
        let data = {};
        try {
            let rules = {
                post_id: `required|mongoId|exists:project_channel_posts,_id`,
                parent_id: `sometimes|mongoId|exists:project_channel_post_comments,_id`,
                comment: `required`
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            let document = {
                'post_id': req.body.post_id,
                'user_id': req.auth.id,
                'parent_id': req.body.parent_id || null,
                'comment': req.body.comment,
            }

            await ProjectChannelPostComment.create(document, function (e, details) {
                if (e) return resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });

                data.comment = new ProjectChannelPostCommentResource(details).exec();
                return resp.status(200).json({ 'status': "success", 'message': "Comment posted successfully", data: data });
            })
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },

    details: async function (req, resp) {
        let data = {};
        try {
            let rules = {
                post_id: `required|mongoId|exists:project_channel_posts,_id`,
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            var filter_option = {
                $match: {
                    $and: [
                        { _id: mongoose.Types.ObjectId(req.body.post_id) },
                        { deleted_at: null },
                        { status: 'active' },
                    ]
                }
            };

            ProjectChannelPost.aggregate([
                filter_option,
                { $lookup: { from: 'users', localField: 'user_id', foreignField: '_id', as: 'user' }, },
                { $lookup: { from: 'project_channel_post_reacts', localField: '_id', foreignField: 'post_id', as: 'reacts' }, },
                {
                    /** GET RECENT REACTIONS */
                    $lookup: {
                        from: 'project_channel_post_reacts',
                        as: 'recent_reacts',
                        let: { post_id: '$_id' },
                        pipeline: [
                            { $match: { $expr: { $eq: ['$post_id', '$$post_id'] } }, },
                            { $lookup: { from: 'users', localField: 'user_id', foreignField: '_id', as: 'user' }, },
                            { $sort: { created_at: 1 } },
                            { $limit: 10 },
                            {
                                $addFields: {
                                    user: { $arrayElemAt: ["$user", 0] },
                                },
                            },
                        ]
                    }
                },
                {
                    /** GET CURRENT USER REACT */
                    $lookup: {
                        from: 'project_channel_post_reacts',
                        as: 'user_react',
                        let: { post_id: '$_id' },
                        pipeline: [
                            { $match: { $expr: { $eq: ['$post_id', '$$post_id'] }, $and: [{ 'user_id': mongoose.Types.ObjectId(req.auth.id) }] }, },
                        ]
                    }
                },
                {
                    $lookup: {
                        from: 'project_channel_post_comments',
                        as: 'comments',
                        let: { post_id: '$_id' },
                        pipeline: [
                            { $match: { $expr: { $eq: ['$post_id', '$$post_id'] }, $and: [{ parent_id: null }] }, },
                            { $lookup: { from: 'users', localField: 'user_id', foreignField: '_id', as: 'user' }, },
                            { $sort: { created_at: -1 } },
                            // { $limit: 10 },
                            {
                                $addFields: {
                                    user: { $arrayElemAt: ["$user", 0] },
                                },
                            },
                        ]
                    },
                },
                {
                    /** GET RECENT COMMENTS */
                    $lookup: {
                        from: 'project_channel_post_comments',
                        as: 'recent_comments',
                        let: { post_id: '$_id' },
                        pipeline: [
                            { $match: { $expr: { $eq: ['$post_id', '$$post_id'] }, $and: [{ parent_id: null }] }, },
                            { $lookup: { from: 'users', localField: 'user_id', foreignField: '_id', as: 'user' }, },
                            { $sort: { created_at: 1 } },
                            { $limit: 10 },
                            {
                                $addFields: {
                                    user: { $arrayElemAt: ["$user", 0] },
                                },
                            },
                        ]
                    }
                },
                {
                    $addFields: {
                        user: { $arrayElemAt: ["$user", 0] },
                        user_react: { $arrayElemAt: ["$user_react", 0] }
                    },
                },
            ]).exec().then(function (details) {
                let post_details = details[0] || null;
                if (post_details) {
                    /**
                     * =================================
                     * SEND CUSTOM SETTINGS TO RESOURCES
                     * =================================
                     * =================================
                     */
                    post_details.RESP_SETTINGS = {
                        reacts_count: true,
                        comments_count: true,
                        user_react: true,
                        comments: true,
                    }

                    post_details = new ProjectChannelPostResource(post_details).exec();
                }

                data.post = post_details;
                return resp.status(200).json({ 'status': "success", 'message': "Success", data: data });
            }).catch(function (e) {
                return resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });
            })
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },
}