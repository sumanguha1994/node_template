const Resource = require('resources.js');
const UserResource = require('./UserResource');

class ProjectChannelPostReactResource extends Resource {
    toArray() {
        let doc = {
            _id: this._id || null,
            user_id: this.user_id || null,
            post_id: this.post_id || null,
            type: this.type || null,
            created_at: this.created_at || null,
            updated_at: this.updated_at || null,
        }

        if (this.user !== undefined) {
            doc.user = new UserResource(this.user).exec();
        }

        return doc;
    }
}

module.exports = ProjectChannelPostReactResource;