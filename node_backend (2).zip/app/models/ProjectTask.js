const mongoose = require('mongoose');
// const mongoosePaginate = require('mongoose-paginate-v2');
const mongooseAggregatePaginate = require('mongoose-aggregate-paginate-v2');

const Schema = mongoose.Schema;

const ProjectTaskSchema = new mongoose.Schema({
    project_id: {
        type: mongoose.Types.ObjectId,
        required: true
    },
    division_id: {
        type: mongoose.Types.ObjectId,
        required: true
    },
    end_date: {
        type: Date,
        required: true
    },
    priority: {
        type: String,
        enum: ["low", "moderate", "high"],
        required: true,
    },
    description: {
        type: String,
        required: true,
    },
    status: {
        type: String,
        enum: ["active", "inactive"],
        required: true,
        default: "active"
    },
    created_at: {
        type: Date,
        required: true,
        default: Date.now
    },
    updated_at: {
        type: Date,
        required: true,
        default: Date.now
    },
    deleted_at: {
        type: Date,
        required: false,
        default: null
    },
});

// ProjectTaskSchema.plugin(mongoosePaginate);
ProjectTaskSchema.plugin(mongooseAggregatePaginate);

const ProjectTask = mongoose.model('project_tasks', ProjectTaskSchema);

module.exports = ProjectTask;