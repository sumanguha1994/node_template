const express = require('express');
const router = express.Router();

// Importing Controllers
const AdminsController = require('../app/controllers/admin/AdminsController');
const MembersController = require('../app/controllers/admin/MembersController');
const MastersController = require('../app/controllers/admin/MastersController');
const ProjectsController = require('../app/controllers/admin/ProjectsController');
const ProjectTasksController = require('../app/controllers/admin/ProjectTasksController.js');
const ProjectTaskUsersController = require('../app/controllers/admin/ProjectTaskUsersController.js');
const ProjectChannelsController = require('../app/controllers/admin/ProjectChannelsController.js');

router.post('/profile/update', AdminsController.updateProfile);

router.post('/members/add', MembersController.add);
router.post('/members/view', MembersController.view);
router.post('/members/edit', MembersController.edit);
router.post('/members/change-status', MembersController.changeStatus);
router.post('/members/create-registration-link', MembersController.createRegistrationLink);
router.post('/members/fetch-master', MembersController.fetchMaster);

router.post('/masters/:type/add', MastersController.add);
router.post('/masters/:type/view', MastersController.view);
router.post('/masters/:type/edit', MastersController.edit);
router.post('/masters/:type/change-status', MastersController.changeStatus);
router.post('/masters/:type/delete', MastersController.delete);

router.post('/projects/add', ProjectsController.add);
router.post('/projects/view', ProjectsController.view);
router.post('/projects/edit', ProjectsController.edit);
router.post('/projects/change-status', ProjectsController.changeStatus);
router.post('/projects/delete', ProjectsController.delete);
router.post('/projects/details', ProjectsController.details);

router.post('/project/task/add', ProjectTasksController.add);
router.post('/project/task/view', ProjectTasksController.view);
router.post('/project/task/edit', ProjectTasksController.edit);
router.post('/project/task/change-status', ProjectTasksController.changeStatus);
router.post('/project/task/delete', ProjectTasksController.delete);
router.post('/project/task/details', ProjectTasksController.details);

router.post('/project/task/user/assign', ProjectTaskUsersController.assign);
router.post('/project/task/user/remove', ProjectTaskUsersController.remove);
router.post('/project/task/user/view', ProjectTaskUsersController.view);
router.post('/project/task/user/fetch-assignes', ProjectTaskUsersController.fetchAssignes);

router.post('/project/channel/users', ProjectChannelsController.users);
router.post('/project/channel/view', ProjectChannelsController.view);
router.post('/project/channel/assign-user', ProjectChannelsController.assignUser);
router.post('/project/channel/remove-user', ProjectChannelsController.removeUser);
router.post('/project/channel/fetch-assignes', ProjectChannelsController.fetchAssignes);

module.exports = router;