const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const ProjectChannelPostReactSchema = new mongoose.Schema({
    post_id: {
        type: mongoose.Types.ObjectId,
        required: true
    },
    user_id: {
        type: mongoose.Types.ObjectId,
        required: true
    },
    type: {
        type: String,
        enum: ["like", "fire", "rock", "support"],
        required: true,
    },
    created_at: {
        type: Date,
        required: true,
        default: Date.now
    },
});

const ProjectChannelPostReact = mongoose.model('project_channel_post_reacts', ProjectChannelPostReactSchema);

module.exports = ProjectChannelPostReact;