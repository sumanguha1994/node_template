// Initialize DOTENV Configuration
const dotenv = require('dotenv');
dotenv.config();

const express = require('express');
const cors = require('cors');

const fileUpload = require('express-fileupload');
// var multer = require('multer');
// var upload = multer();

// Importing Configuration files to Global
global.CONFIG = {
    DIR_PATH: __dirname,
    rules: require('./config/rules'),
    bcrypt: require('./config/bcrypt'),
    app: require('./config/app'),
    mail: require('./config/mail'),
}

// Importing Middleware
const AuthMiddleware = require('./app/middleware/AuthMiddleware');

// Initialize expressJS
const app = express();

// Initialize MongoDB Connection
const mongoose = require('./config/mongoose');

// Initializing CORS
app.use(cors());

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
// app.use(upload.any());
app.use(fileUpload());
app.use(express.static('public'));

// Initializing Routes
app.use(process.env.SERVER_BASEPATH + '/auth', require('./routes/auth'));
app.use(process.env.SERVER_BASEPATH + '/admin', AuthMiddleware.checkAuth, AuthMiddleware.checkRole(['superadmin']), require('./routes/admin'));
app.use(process.env.SERVER_BASEPATH + '/web', AuthMiddleware.checkAuth, AuthMiddleware.checkRole(['manager', 'employee', 'contractor', 'supplier', 'safety_manager']), require('./routes/web'));
app.use(process.env.SERVER_BASEPATH + '/public', express.static('./public'));
app.use(process.env.SERVER_BASEPATH + '/', require('./routes/index'));


// Initializing the Server
app.listen(process.env.SERVER_PORT, process.env.SERVER_HOSTNAME, () => {
    console.log(`Server running at http://${process.env.SERVER_HOSTNAME}:${process.env.SERVER_PORT}/`);
});