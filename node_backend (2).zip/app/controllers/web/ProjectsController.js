const userhelpers = require('../../common/userhelpers');
const helpers = require('../../common/helpers');

const Project = require('../../models/Project');
const Division = require('../../models/Division');
const User = require('../../models/User');
const ProjectResource = require('../../resources/ProjectResource');
const DivisionResource = require('../../resources/DivisionResource');
const UserResource = require('../../resources/UserResource');
const mongoose = require('mongoose');

module.exports = {
    list: async function (req, resp) {
        let data = {};
        try {
            const accessibleProjects = await userhelpers.getAccessibleProjects(req.auth.id);

            data.projects = [];
            await Project.find({ '_id': { "$in": accessibleProjects }, 'status': 'active', 'deleted_at': null }).exec().then((projects) => {
                return data.projects = ProjectResource.collection(projects);
            }).catch((err) => {
                resp.status(200).send({ status: 'error', message: err ? err.message : 'DB Error Occured', data: data });
                process.exit(1);
            })

            return resp.status(200).send({ status: 'success', message: 'Success', data: data });
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },

    details: async function (req, resp) {
        let data = {};
        try {
            rules = {
                project_id: `sometimes|mongoId|exists:projects,_id`,
                project_slug: `sometimes|exists:projects,slug`,
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            /**
             * ---------------------
             * FETCH PROJECT DETAILS
             * ---------------------
             * ---------------------
             */

            let condition = {
                "_id": { "$in": await userhelpers.getAccessibleProjects(req.auth.id) }
            };

            if (req.body.project_id) {
                condition._id.$eq = req.body.project_id;
            } else if (req.body.project_slug) {
                condition.slug = req.body.project_slug;
            } else {
                return resp.status(200).send({ status: 'error', message: 'Project ID or SLUG, anyone must be available', data: data });
            }

            let project_details = null;
            await Project.findOne(condition).exec().then(function (result) {
                return project_details = result
            }).catch((err) => {
                resp.status(200).send({ status: 'error', message: err ? err.message : 'DB Error Occured', data: data });
                process.exit(1);
            })

            if (!project_details) {
                return resp.status(200).send({ status: 'error', message: 'Project not found', data: data });
            }


            /**
             * ----------------------------------
             * FETCH PROJECT CHANNELS / DIVISIONS
             * ----------------------------------
             * ----------------------------------
             */

            const accessibleDivisions = await userhelpers.getAccessibleProjectDivisions(req.auth.id, project_details._id, {
                division_id: mongoose.Types.ObjectId(req.auth.data.division_id)
            })

            data.divisions = [];
            await Division.find({ '_id': { "$in": accessibleDivisions } }).exec().then((divisions) => {
                return data.divisions = DivisionResource.collection(divisions);
            }).catch((err) => {
                resp.status(200).send({ status: 'error', message: err ? err.message : 'DB Error Occured', data: data });
                process.exit(1);
            })


            data.project = new ProjectResource(project_details).exec();
            return resp.status(200).send({ status: 'success', message: 'Success', data: data });
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }

    },

    members: async function (req, resp) {
        let data = {};
        try {
            rules = {
                project_id: `required|mongoId|exists:projects,_id`,
                division_id: `sometimes|mongoId|exists:divisions,_id`,
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            data.users = [];
            
            const usersIdsAssigned = await userhelpers.fetchProjectChannelAssignedMembers(req.body.project_id, req.body.division_id);
            if (usersIdsAssigned.length > 0) {
                await User.find({
                    'role': { "$in": ['manager', 'employee', 'contractor', 'supplier', 'safety_manager'] },
                    '_id': { "$nin": usersIdsAssigned },
                    'status': "active",
                    'division_id': req.body.division_id,
                    'deleted_at': null
                }, '').sort({ 'name': 1 }).exec().then(function (users) {
                    return data.users = UserResource.collection(users);
                });
            }

            return resp.status(200).send({ status: 'success', message: 'Success', data: data });
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },

    /**
     * ----------------------------
     * ACCESSIBLE ONLY FOR MANAGERS
     * ----------------------------
     */
    create: async function (req, resp) {
        let data = {};
        try {
            let rules = {
                name: `required`,
                location: `required`,
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            let document = {
                'name': req.body.name,
                'slug': await helpers.generateCollectionSlug(Project, req.body.name, 'slug'),
                'location': req.body.location,
                'created_by': req.auth.id
            }

            if (req.files && req.files.image !== undefined) {
                const uploadImage = await helpers.uploadFile(req.files.image, 'projects');
                if (uploadImage.status == false) {
                    return resp.status(200).json({ 'status': "error", 'message': "File upload error : " + uploadImage.message, data: data });
                }

                document.image = uploadImage.filename;
            } else {
                return resp.status(200).json({ 'status': "error", 'message': "The image field is mandatory.", data: data });
            }

            Project.create(document, async function (e, details) {
                if (e) return resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });

                data.project = new ProjectResource(details).exec();

                return resp.status(200).json({ 'status': "success", 'message': "Project created successfully", data: data });
            })
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },

    update: async function (req, resp) {
        let data = {};
        try {
            let rules = {
                project_id: `required|mongoId|exists:projects,_id`,
                name: `required`,
                location: `required`,
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            let project_details = await Project.findOne({ '_id': req.body.project_id, deleted_at: null }).exec().then(function (row) {
                return row;
            }).catch(function (e) {
                resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });
                process.exit(1);
            })

            if (!project_details) {
                return resp.status(404).send({ status: 'error', message: 'Project Not Found', data: data });
            }

            if (project_details.created_by != req.auth.id) {
                return resp.status(404).send({ status: 'error', message: 'You don\'t have permission to edit this product', data: data });
            }

            var document = {
                name: req.body.name,
                slug: await helpers.generateCollectionSlug(Project, req.body.name, 'slug', req.body.project_id),
                location: req.body.location,
                updated_at: Date.now(),
            };

            if (req.files && req.files.image !== undefined) {
                const uploadImage = await helpers.uploadFile(req.files.image, 'projects');
                if (uploadImage.status == false) {
                    return resp.status(200).json({ 'status': "error", 'message': "File upload error : " + uploadImage.message, data: data });
                }

                if (project_details.image) {
                    await helpers.deleteFile(project_details.image, 'projects');
                }

                document.image = uploadImage.filename;
            }

            await Project.updateOne({ '_id': req.body.project_id }, document, async function (err, details) {
                if (err) {
                    return resp.status(200).send({ status: 'error', message: err ? err.message : 'DB Error Occured', data: data });
                }

                data.project = null;
                await Project.findOne({ _id: req.body.project_id }, '',).exec().then(function (project) {
                    return data.project = new ProjectResource(project).exec();
                })

                return resp.status(200).send({ status: 'success', message: 'Project updated successfully', data: data });
            })
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },

    delete: async function (req, resp) {
        let data = {};
        try {
            rules = {
                project_id: `required|mongoId|exists:projects,_id`,
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            let project_details = await Project.findOne({ '_id': req.body.project_id, deleted_at: null }).exec().then(function (row) {
                return row;
            }).catch(function (e) {
                resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });
                process.exit(1);
            })

            if (!project_details) {
                return resp.status(404).send({ status: 'error', message: 'Project Not Found', data: data });
            }

            if (project_details.created_by != req.auth.id) {
                return resp.status(404).send({ status: 'error', message: 'You don\'t have permission to edit this product', data: data });
            }

            var document = {
                deleted_at: Date.now(),
            };

            await Project.updateOne({ '_id': req.body.project_id }, document, async function (err, details) {
                if (err) {
                    return resp.status(200).send({ status: 'error', message: err ? err.message : 'DB Error Occured', data: data });
                }

                return resp.status(200).send({ status: 'success', message: "Project deleted successfully", data: data });
            })
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    }
}