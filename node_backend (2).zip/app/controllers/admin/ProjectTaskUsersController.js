const mongoose = require('mongoose');
const helpers = require('../../common/helpers');

const User = require('../../models/User');
const ProjectTaskUser = require('../../models/ProjectTaskUser');
const UserResource = require('../../resources/UserResource');
const ProjectTaskUserResource = require('../../resources/ProjectTaskUserResource');
const ProjectTaskResource = require('../../resources/ProjectTaskResource');
const ProjectTask = require('../../models/ProjectTask');
const ProjectChannelUser = require('../../models/ProjectChannelUser');

module.exports = {
    view: async function(req, resp) {
        let data = {};
        try {
            rules = {
                task_id: `required|mongoId|exists:project_tasks,_id`,
                pageno: `required|numeric`,
                searchkey: `nullable`,
                length: `nullable`,
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            const options = {
                page: req.body.pageno,
                limit: req.body.length ? req.body.length : global.CONFIG.app.pagination.perpage,
                sort: { created_at: -1 },
            };

            var filter_option = {
                $match: {
                    $and: [{
                        'task_id': mongoose.Types.ObjectId(req.body.task_id),
                        'deleted_at': null
                    }]
                }
            };

            if (req.body.searchkey) {
                filter_option.$match.$or = [
                    { "status": { $regex: ".*" + req.body.searchkey + ".*" } },
                ];
            }

            var projectTaskUserAggregrate = ProjectTaskUser.aggregate([
                filter_option,
                {
                    $lookup: {
                        from: 'project_tasks',
                        localField: 'task_id',
                        foreignField: '_id',
                        as: 'task'
                    },
                    $lookup: {
                        from: 'users',
                        localField: 'user_id',
                        foreignField: '_id',
                        as: 'user'
                    }
                },
                {
                    $addFields: {
                        task: {
                            $arrayElemAt: ["$task", 0]
                        },
                        user: {
                            $arrayElemAt: ["$user", 0]
                        },
                    }
                },
            ]);

            ProjectTaskUser.aggregatePaginate(projectTaskUserAggregrate, options, function(e, rows) {
                if (e) return resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });

                rows.docs = ProjectTaskUserResource.collection(rows.docs);

                data.project_task_users = rows
                return resp.status(200).json({ status: 'success', 'message': 'Task users fetched successfully', data: data });
            })
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },

    assign: async function(req, resp) {
        let data = {};
        try {
            let rules = {
                task_id: `required|mongoId|exists:project_tasks,_id`,
                user_id: `required|mongoId|exists:users,_id`,
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            let document = {
                'task_id': req.body.task_id,
                'user_id': req.body.user_id,
                'deleted_at': null
            }

            let taskUserCount = 0;
            await ProjectTaskUser.countDocuments(document).exec().then(function(count) {
                return taskUserCount = count;
            })

            if (taskUserCount > 0) {
                return resp.status(200).send({ status: 'error', message: 'The user is already assigned to this task', data: data });
            }

            ProjectTaskUser.create(document, async function(e, details) {
                if (e) return resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });

                data.project_task_user = new ProjectTaskUserResource(details).exec();

                return resp.status(200).json({ 'status': "success", 'message': "The task assigned to the user successfully", data: data });
            })
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },

    remove: async function(req, resp) {
        let data = {};
        try {
            let rules = {
                task_id: `required|mongoId|exists:project_tasks,_id`,
                user_id: `required|mongoId|exists:users,_id`,
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            let document = {
                'task_id': req.body.task_id,
                'user_id': req.body.user_id,
                'deleted_at': null,
            }

            let taskUserCount = 0;
            await ProjectTaskUser.countDocuments(document).exec().then(function(count) {
                return taskUserCount = count;
            })

            if (!taskUserCount) {
                return resp.status(200).send({ status: 'error', message: 'The user is not assigned to this task', data: data });
            }

            ProjectTaskUser.updateOne(document, { deleted_at: Date.now() }, async function(e, details) {
                if (e) return resp.status(200).json({ 'status': "error", 'message': e ? e.message : 'DB Error Occured', data: data });

                return resp.status(200).json({ 'status': "success", 'message': "The user removed from the task successfully", data: data });
            })
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },

    fetchAssignes: async function(req, resp) {
        let data = {};
        try {
            rules = {
                task_id: `required|mongoId|exists:project_tasks,_id`,
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            /**
             * -----------------------------------------
             * FETCH USERS ASSIGNED ALEREADY IN THE TASK
             * -----------------------------------------
             */
            let usersIdsAssigned = []
            await ProjectTaskUser.find({ 'task_id': req.body.task_id, 'deleted_at': null }).select('user_id').exec().then(function(results) {
                results.forEach(element => {
                    usersIdsAssigned.push(element.user_id);
                });
            })


            /**
             * ------------------
             * FETCH TASK DETAILS
             * ------------------
             */
            let projecttask_details = null;
            await ProjectTask.aggregate([{
                    $match: {
                        $and: [{
                            '_id': mongoose.Types.ObjectId(req.body.task_id),
                            'deleted_at': null
                        }]
                    }
                },
                {
                    $lookup: {
                        from: 'projects',
                        localField: 'project_id',
                        foreignField: '_id',
                        as: 'project'
                    }
                },
                {
                    $addFields: {
                        project: {
                            $arrayElemAt: ["$project", 0]
                        },
                    }
                },
            ]).exec().then(function(result) {
                let details = result[0] ? result[0] : null;
                if (details) {
                    return projecttask_details = new ProjectTaskResource(details).exec();
                }
            });

            if (!projecttask_details) {
                return resp.status(200).send({ status: 'error', message: 'Project task not found', data: data });
            }


            /**
             * -----------------------------------
             * FETCH USERS ASSIGNED IN THE CHANNEL
             * -----------------------------------
             */
            let channelUsers = []
            await ProjectChannelUser.find({ 'project_id': projecttask_details.project_id, 'division_id': projecttask_details.division_id, 'deleted_at': null }).select('user_id').exec().then(function(results) {
                results.forEach(element => {
                    channelUsers.push(element.user_id);
                });
            })


            data.project_task = projecttask_details;
            data.users = [];
            await User.find({
                'role': { "$in": ['manager', 'employee', 'contractor', 'supplier', 'safety_manager'] },
                '_id': { "$nin": usersIdsAssigned, "$in": channelUsers },
                'division_id': projecttask_details.division_id,
                'status': "active",
                'deleted_at': null
            }, '').sort({ 'name': 1 }).exec().then(function(users) {
                return data.users = UserResource.collection(users);
            });

            return resp.status(200).send({ status: 'success', message: "Success", data: data });
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    },

    changeStatus: async function(req, resp) {
        let data = {};
        try {
            rules = {
                assigne_id: `required|mongoId|exists:project_task_users,_id`,
                status: `required|in:pending,inprogress,completed`,
            };

            const v = await helpers.validator(rules, req.body);
            if (!v.status) {
                data.errors = v.errors;
                return resp.status(200).json({ 'status': "val_error", 'message': "Validation Error", data: data });
            }

            let document = {
                'status': req.body.status,
                'updated_at': Date.now()
            }

            await ProjectTaskUser.updateOne({ '_id': req.body.assigne_id }, document, async function(err, details) {
                if (err) {
                    return resp.status(200).send({ status: 'error', message: err ? err.message : 'DB Error Occured', data: data });
                }

                return resp.status(200).send({
                    status: 'success',
                    message: "Status updated successfully",
                    data: data
                });
            })
        } catch (e) {
            return resp.status(200).send({ status: 'error', message: e ? e.message : 'Something went wrong', data: data });
        }
    }
}